import argparse
import datetime



from scripts import create_db, extractdatactrldb, generateHtml, dataforrepport
from scripts.courriel import courriel
from utils import ctrlprodenv

if __name__ == "__main__" :

    print("Main ")
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', help='DataBase  ([init], [back])')
    parser.add_argument('--reedition' , help='mode réédition mail (:) [Yes] , [No] par defaut :No  ')
    args = parser.parse_args()

    env_app = ctrlprodenv.Env()
    meteo = dataforrepport.start(env_app)
    # htmlInfg = generateHtml.start(env_app,meteo, 'INFG')
    htmlInfg = generateHtml.start(env_app,meteo, 'MYGREFFE')
    print(htmlInfg)