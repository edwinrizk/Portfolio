import sqlite3
from builtins import print
from sqlite3 import Error


def get_ErreurJudiciaire(db, paramidtrt, type):
    conn = create_connection(db)
    data = (paramidtrt,)

    cur = conn.cursor()
    if type == 'INF':
        sql = ''' SELECT ctrljud_gr_nume || '  ' || ctrljud_gr_nom, ctrljud_daterejet, ctrljud_libellerej, ctrljud_nbrej ,ctrljud_gr_gp
                    from dashboard_ctrljud 
                   Where idtrt = ? and ctrljud_nbrej != ' - ' order by ctrljud_gr_gp, ctrljud_gr_nume desc '''
    else:
        sql = ''' SELECT ctrljud_gr_nume || '  ' || ctrljud_gr_nom, ctrljud_daterejet, ctrljud_libellerej, ctrljud_nbrej ,ctrljud_gr_gp
                        from dashboard_ctrljud 
						
						Where idtrt = ? and ctrljud_nbrej != ' - '  and ctrljud_gr_gp_old  in ('01','05','03','40') order by ctrljud_gr_gp, ctrljud_gr_nume desc '''

    cur.execute(sql, data)

    lst = cur.fetchall()

    return lst


def get_lstAllDateFraicheur(db, paramidtrt):
    conn = create_connection(db)
    data = (paramidtrt,)

    cur = conn.cursor()
    cur.execute('''
                    SELECT   case when greffe_num in ("5751","5752","5753","6751","6752","6851","6852") then "Tribunal Judiciaire"
                                  when greffe_num  = '7501' then "PARIS"  
                                  else greffe_groupe_nom
	                         end  as greffe_groupe_nom 
                            , domaine
                            , group_concat(greffe_num || ' ' || greffe_nom,"\n")
                            , group_concat (strftime('%d.%m.%Y',date_fraicheur),"\n")
                      from dashboard_ctrldatefraicheur Where idtrt = ?
                  group by case when greffe_num in ("5751","5752","5753","6751","6752","6851","6852") then "Tribunal Judiciaire"
                                else  greffe_groupe_nom
	                       end , domaine
                  order by greffe_groupe_nom, domaine, date_fraicheur asc ''',
                data)
    lst = cur.fetchall()
    print(lst)
#    if (lst[0][0] == None and lst[0][1] == None and lst[0][2] == None and lst[0][3] == None):
 #       del lst[0]

    return lst


def get_lstMyGreffeDateFraicheur(db, paramidtrt):
    conn = create_connection(db)
    data = (paramidtrt,)

    cur = conn.cursor()
    cur.execute('''
                    SELECT   case when greffe_num in ("5751","5752","5753","6751","6752","6851","6852") then "Tribunal Judiciaire"
                                  else greffe_groupe_nom
	                         end  as greffe_groupe_nom 
                            , domaine
                            , group_concat(greffe_num || ' ' || greffe_nom,"\n")
                            , group_concat (strftime('%d.%m.%Y',date_fraicheur),"\n")
                      from dashboard_ctrldatefraicheur 
                  
                      Where idtrt = ?  and greffe_groupe_nom in ('MYGREFFE','AGORA')
                  group by case when greffe_num in ("5751","5752","5753","6751","6752","6851","6852") then "Tribunal Judiciaire"
                                else  greffe_groupe_nom
	                       end , domaine
                  order by greffe_groupe_nom, domaine, date_fraicheur asc ''',
                data)
    lst = cur.fetchall()
#    if (lst[0][0] == None and lst[0][1] == None and lst[0][2] == None and lst[0][3] == None):
 #       del lst[0]

    return lst


def get_lstdatefraicheur(db, paramidtrt, paramgp, paramdomaine):
    conn = create_connection(db)
    data = (paramidtrt, paramgp, paramdomaine)

    cur = conn.cursor()
    cur.execute('''SELECT greffe_num , greffe_nom, strftime('%d.%m.%Y',date_fraicheur) FROM dashboard_ctrldatefraicheur  
                        WHERE idtrt = ? and greffe_groupe_num =?  and domaine = ?
                        order by domaine,greffe_groupe_num,date_fraicheur
                      ''',
                data)
    for item in cur.fetchall():
        print(item)


def get_lstDateFraicheur(db, paramidtrt, domaine, greffe_groupe_num):
    conn = create_connection(db)
    data = (paramidtrt, domaine, greffe_groupe_num)

    cur = conn.cursor()
    cur.execute(''' SELECT  greffe_groupe_nom,  group_concat(greffe_num || ' ' || greffe_nom,"\n"), group_concat (strftime('%d.%m.%Y',date_fraicheur),"\n")
                   from dashboard_ctrldatefraicheur Where idtrt = ?  and domaine = ? and greffe_groupe_num = ? 
                   order by date_fraicheur asc
                    ''',
                data)
    lst = cur.fetchall()

    print((lst))
 #   if (lst[0][0] == None and lst[0][1] == None and lst[0][2] == None):
 #       del lst[0]

    print(lst)
    print(len(lst))
    return lst


def get_CompteurCentralRcsXml(db, paramidtrt):
    conn = create_connection(db)
    data = (paramidtrt,)

    cur = conn.cursor()
    cur.execute(''' SELECT ctrlcentxml_type, INFOGREFFE, AGORA, NOUMEA, MYGREFFE, GAGI, PARIS, INTERGREFFE 
                    from dashboard_ctrlcentxml Where idtrt = ? order by ctrlcentxml_type desc ''',
                data)
    lst = cur.fetchall()
    return lst


def get_CompteurGeideAllGrp(db, paramidtrt, type):
    conn = create_connection(db)
    data = (paramidtrt, type)

    cur = conn.cursor()
    cur.execute(''' SELECT  Documents, 
    Ifnull(INFOGREFFE,0), 
    Ifnull(AGORA,0), 
    Ifnull(NOUMEA,0) , 
    Ifnull(MYGREFFE,0),  
    Ifnull(TITMC,0),
    Ifnull(GAGI,0), 
    Ifnull(PARIS,0), 
    Ifnull(INTERGREFFE ,0),  chrono
                    from dashboard_ctrlgedcompteur Where idtrt = ? and  type = ?  order by chrono asc ''',
                data)
    lst = cur.fetchall()

    return lst


def get_CompteurGeideMyGreffe(db, paramidtrt, type):
    conn = create_connection(db)
    data = (paramidtrt, type)

    cur = conn.cursor()
    cur.execute(''' SELECT  Documents, Ifnull(INFOGREFFE,0), Ifnull(AGORA,0), Ifnull(NOUMEA,0) , Ifnull(MYGREFFE,0),  Ifnull(TITMC,0),  chrono
                    from dashboard_ctrlgedcompteur Where idtrt = ? and  type = ? order by chrono asc ''',
                data)
    lst = cur.fetchall()

    return lst


def get_LstGrfGeideOutAllGrp(db, paramidtrt):
    conn = create_connection(db)
    data = (paramidtrt,)

    cur = conn.cursor()
    cur.execute(''' SELECT  Documents,  Ifnull(INFOGREFFE," "),  Ifnull(AGORA," "),  Ifnull(NOUMEA," "),  Ifnull(MYGREFFE," "),  
                           Ifnull(TITMC," "), Ifnull(GAGI," "),  Ifnull(PARIS," "),  Ifnull(INTERGREFFE," ")
                    from dashboard_ctrlgedlstgreffesmanquant  Where  idtrt = ?  order by chrono asc ''', data)
    lst = cur.fetchall()

    return lst


def get_LstGrfGeideOutMyGreffe(db, paramidtrt):
    conn = create_connection(db)
    data = (paramidtrt,)

    cur = conn.cursor()
    cur.execute(''' SELECT  Documents,  Ifnull(INFOGREFFE," "),  Ifnull(AGORA," "),  Ifnull(NOUMEA," "),  Ifnull(MYGREFFE," "),  
                           Ifnull(TITMC," ")
                    from dashboard_ctrlgedlstgreffesmanquant  Where  idtrt = ?  order by chrono asc ''', data)
    lst = cur.fetchall()

    return lst


def getIdTrt(db):
    conn = create_connection(db)
    with conn:
        try:
            cur = conn.cursor()

            cur.execute(''' select ifnull( max(idtrt),0) from dashboard_traitement''')
            row = cur.fetchone()

            return row[0]

        except Error as e:
            print(e)


def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by the db_file
    :param db_file: database file
    :return: Connection object or None
    """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)

    return conn
