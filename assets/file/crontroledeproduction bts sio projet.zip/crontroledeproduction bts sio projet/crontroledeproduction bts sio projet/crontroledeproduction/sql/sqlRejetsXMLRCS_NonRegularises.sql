 select       CER_RG_C as "Code erreur"   ,CRG_RG_L   as "Libellé erreur"    ,
   SUM (CASE WHEN CED_GR_NUME IN (SELECT GR_NUME FROM E_GREFFE WHERE FS_VERIF_GREFFE_OUVERT(GR_NUME, NULL, 'MYGREFFE')  = 1)                    THEN 1 ELSE 0 END)  as "MYGREFFE",
   SUM (CASE WHEN CED_GR_NUME IN (SELECT GR_NUME FROM E_GREFFE WHERE FS_VERIF_GREFFE_OUVERT(GR_NUME, NULL, 'DIFFUSION') = 1 AND GR_NUME <> '7501') THEN 1 ELSE 0 END)  as "GAGI",
   SUM (CASE WHEN CED_GR_NUME IN (SELECT GR_NUME FROM E_GREFFE WHERE FS_VERIF_GREFFE_OUVERT(GR_NUME, NULL, 'DIFFUSION') = 1 AND GR_NUME  = '7501') THEN 1 ELSE 0 END)  as "PARIS",
   SUM (CASE WHEN CED_GR_NUME IN (SELECT GR_NUME FROM E_GREFFE WHERE FS_VERIF_GREFFE_OUVERT(GR_NUME, NULL, 'INTERGRF')  = 1)  THEN 1 ELSE 0 END)  as INTERGREFFE,
      SUM (CASE WHEN CED_GR_NUME IN (SELECT GR_NUME FROM E_GREFFE WHERE FS_VERIF_GREFFE_OUVERT(GR_NUME, NULL, 'GREFTEL')   = 1 AND GR_NUME <> '9812') THEN 1 ELSE 0 END)  as "Trib-JUD",
   SUM (CASE WHEN CED_GR_NUME IN (SELECT GR_NUME FROM E_GREFFE WHERE FS_VERIF_GREFFE_OUVERT(GR_NUME, NULL, 'GREFTEL')   = 1 AND GR_NUME = '9812') THEN 1 ELSE 0 END)  as "NOUMEA"





from e_cent_dossier a,    e_cent_ctrl_err , e_cent_reg_gestion
where 1=1
-- en rejet
and nvl(a.CED_SUPPRIME_ON, '0') = '0'
and a.ced_etat_c = 'KO'
and  cer_dos_id = a.ced_dos_id
and cer_rg_c not in ('RG1', 'RG999')
and CER_BLOQUANT_ON = '1'
and crg_rg_c = cer_rg_c
-- non  suivi d'une autre transmission
and not exists
(select 1 from e_cent_dossier b
where a.CED_GR_NUME    = b.CED_GR_NUME
and a.CED_DO_MIL       = b.CED_DO_MIL
and a.CED_DO_ST_C      = b.CED_DO_ST_C
and a.CED_DO_CHRONO    = b.CED_DO_CHRONO
and b.CED_creat_D  > a.CED_creat_D
)

--
group by CER_RG_C     ,CRG_RG_L
order by CER_RG_C