select * from (
    select doctyp_c ,groupement ,to_char(LISTAGG(gr_nume ||' ' || gr_nom , ' ' || chr(13))
                                                 WITHIN GROUP (ORDER BY gr_nume)) as liste_greffes
    from (
             select case  when doc.gdt_doctyp_c in ('BILAN', 'COMPTE_RES', 'DECL_CF_CR', 'DECL_CONF') then 'BILANS' else
                 gdt_doctyp_c end as doctyp_c
                  ,gr_nume ,gr_nom ,fs_groupement(gr_nume) as groupement
             from e_greffe
                      join e_ged_doctype doc on doc.gdt_doctyp_c in
                                                ( 'BILAN','COMPTE_RES','DECL_CF_CR','DECL_CONF', 'ACTE','BILAN','LIASSEART3')
             where fs_verif_greffe_ouvert(gr_nume, '01 02 03 05 20 51 40', null) = 1
             group by gr_nume, gr_nom, fs_groupement(gr_nume),
                      case  when doc.gdt_doctyp_c in
                                 ('BILAN', 'COMPTE_RES', 'DECL_CF_CR', 'DECL_CONF') then 'BILANS' else  doc.gdt_doctyp_c end
         ),
         (
             select case  when ged_doctyp_c in
                               ('BILAN', 'COMPTE_RES', 'DECL_CF_CR', 'DECL_CONF') then 'BILANS' else ged_doctyp_c end as ged_doctyp_c,
                    ged_gr_nume, count(1) as nbdoc
             from e_ged_lot gl
                      left join e_ged_document gd on  gd.ged_lot_id = gl.gel_lot_id
             where 1=1
               and  gl.gel_trait_debut_d >  to_date(  to_char(sysdate - 4 ,'dd/mm/yyyy') || ' 08:00:00' , 'dd/mm/yyyy hh24:MI:SS')
               and GEL_NOMLOT not like '%RET%'
             group by   case  when ged_doctyp_c in
                                   ('BILAN', 'COMPTE_RES', 'DECL_CF_CR', 'DECL_CONF') then 'BILANS' else ged_doctyp_c end,
                        ged_gr_nume
         )
    where ged_gr_nume(+) = gr_nume
      and ged_doctyp_c (+) = doctyp_c
      and ged_gr_nume is null
    group by doctyp_c, groupement
    union all


    select doctyp_c ,groupement ,to_char(LISTAGG(gr_nume ||' ' || gr_nom , ' ' || chr(13))
                                                 WITHIN GROUP (ORDER BY gr_nume)) as liste_greffes
    from (
             select 'JUDICIAIRE' as doctyp_c
                  ,gr_nume ,gr_nom ,nvl(fs_groupement_jud(gr_nume),fs_groupement(gr_nume)) as groupement
             from e_greffe
                      join e_ged_doctype doc on doc.gdt_doctyp_c ='JUDICIAIRE'
             where fs_verif_greffe_ouvert(gr_nume, '01 02 03 05 20 51 40', null) = 1
             group by gr_nume, gr_nom, nvl(fs_groupement_jud(gr_nume), fs_groupement(gr_nume))

         ),
         (
             select 'JUDICIAIRE' as ged_doctyp_c,
                    ged_gr_nume, count(1) as nbdoc
             from e_ged_lot gl
                      left join e_ged_document gd on  gd.ged_lot_id = gl.gel_lot_id and ged_doctyp_c = 'JUDICIAIRE'
             where 1=1
               and  gl.gel_trait_debut_d >  to_date(  to_char(sysdate - 4 ,'dd/mm/yyyy') || ' 08:00:00' , 'dd/mm/yyyy hh24:MI:SS')

               and GEL_NOMLOT not like '%RET%'
             group by
                 ged_gr_nume
         )
    where ged_gr_nume(+) = gr_nume
      and ged_doctyp_c (+) = doctyp_c
      and ged_gr_nume is null
    group by doctyp_c, groupement
)
    pivot ( max(liste_greffes ) for groupement in
        ('Inf. Informatique','GAGI','PARIS','AGORA','INTERGREFFE','MYGREFFE','TI / TMC','NOUVELLE-CALEDONIE') )
;