-- clients MULTI
select est_trait_client
from e_surv_tracage
where est_trait_client not  like 'K%'
and est_trait_nom =  'IPMULTIREV1.sh'
and EST_TRAIT_OK_KO    = 'KO'
and est_trait_d > (select to_date(gpt_val, 'DD/MM/YYYY') from g_parm_trait where GPT_RD_C = 'COM' and  GPT_CP_C      = 'D_DATE_TRT')
