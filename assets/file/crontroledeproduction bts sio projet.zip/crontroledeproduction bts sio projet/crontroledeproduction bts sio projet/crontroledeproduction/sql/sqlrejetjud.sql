select gr_gp_nume as gp,
       gr_ancien_gp_nume as gpold,
       jrj_code_rejet as coderejt,
        jrj_gr_nume as Greffe,
        gr_nom as Nom ,  trunc(jrj_date) as "Date" ,
  jrj_code_rejet || ' - ' ||  crj_comment  as Rejet , count(*) as Nombre
from ej_rejet@LK_SUIVISI_JUDDIFP.WORLD, e_conv_rejet@LK_SUIVISI_JUDDIFP.WORLD, e_greffe
where jrj_maj_d is null
and jrj_date >= sysdate - 3
and jrj_code_rejet = CRJ_CODE_REJET
and gr_nume = jrj_gr_nume
and jrj_code_rejet != 'F0O08'
group by jrj_gr_nume, trunc(jrj_date),  jrj_code_rejet, crj_comment, gr_gp_nume, gr_ancien_gp_nume, gr_nom
having count(*) > 10
order by trunc(jrj_date), count(*)
