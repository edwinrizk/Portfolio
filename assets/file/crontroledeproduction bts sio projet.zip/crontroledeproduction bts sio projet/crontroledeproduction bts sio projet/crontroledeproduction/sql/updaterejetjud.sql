update ej_rejet j
set j.jrj_maj_d = trunc(sysdate)
where j.jrj_maj_d is null
and exists (select 1 from ej_rejet d
where j.jrj_gr_nume = d.jrj_gr_nume
and j.jrj_dossier = d.jrj_dossier
and trunc(d.jrj_date) > trunc(j.jrj_date) )

