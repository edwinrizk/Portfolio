select 'RCS',g.gr_gp_nume, r.gp_l, g.gr_nume, g.gr_nom, trunc(max(d.ced_creat_d))
from e_greffe g, e_cent_dossier d, e_groupement r
where g.gr_nume = d.ced_gr_nume
and g.gr_gp_nume = r.gp_nume
and fs_verif_greffe_ouvert(g.gr_nume, null, null) = 1
and d.ced_do_st_c  <> 'F'
and g.gr_nume not in
(
select c.ced_gr_nume
from e_cent_dossier c
where c.ced_gr_nume in (
select g.gr_nume from e_greffe g where fs_verif_greffe_ouvert(g.gr_nume, null, null) = 1  )
and c.ced_do_st_c  <> 'F'
and c.ced_creat_d >= (select to_date(t1.gpt_val, 'DD/MM/YYYY HH24:MI:SS') + 21/24  from g_parm_trait t1 where t1.gpt_cp_c = 'D_DATE_TRT' )
and c.ced_creat_d < (select to_date(t2.gpt_val, 'DD/MM/YYYY') + 2 from g_parm_trait t2 where t2.gpt_cp_c = 'D_DATE_TRT' )
)
group by g.gr_gp_nume, r.gp_l, g.gr_nume, g.gr_nom
order by g.gr_gp_nume, r.gp_l, g.gr_nume, g.gr_nom
;