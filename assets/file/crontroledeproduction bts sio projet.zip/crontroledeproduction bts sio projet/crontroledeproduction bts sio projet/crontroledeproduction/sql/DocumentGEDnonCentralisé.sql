select  l.gel_origin_c , l.gel_lot_id, l.gel_nb_doc,
case when gd.ged_lot_id is null then 0
   else count(*)
end ,
l.gel_nb_doc -  case when gd.ged_lot_id is null then 0
   else count(*)
end
from e_ged_lot l
left join e_ged_document gd on gd.ged_lot_id = l.gel_lot_id
where 1 = 1
and l.gel_trait_debut_d >= trunc (sysdate -3 )
group by l.gel_origin_c , gel_lot_id, l.gel_nb_doc, ged_lot_id
having (l.gel_nb_doc -  case when gd.ged_lot_id is null then 0
   else count(*) end)  <> 0
   order by  4,  5 desc;
