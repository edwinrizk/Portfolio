/* -- Nombre de demande RECU */
select --gd.ged_diff_c, /* gd.ged_erreur_c, */
(case when ged_doctyp_c = 'ACTE'  then 'Acte'
      when ged_doctyp_c = 'LIASSEART3'  then 'Liasseart3'
   --  when ged_doctyp_c = 'JUDICIAIRE'  then 'Judiciaire'
     Else 'Bilan'

  end ) as "Documents",

sum(case when fs_groupement(ged_gr_nume) = 'Inf. Informatique' /*DEDALE*/  then 1 else 0 end) as "infogreffe",
sum(case when fs_groupement(ged_gr_nume) = 'AGORA'  then 1 else 0 end) as "Agora",
sum(case when fs_groupement(ged_gr_nume) = 'NOUVELLE-CALEDONIE'  then 1 else 0 end) as "Nouméa",
sum(case when fs_groupement(ged_gr_nume) = 'MYGREFFE'  then 1 else 0 end) "MyGreffe" ,
sum(case when fs_groupement(ged_gr_nume) = 'GAGI'  then 1 else 0 end) as "GAGI",
sum(case when fs_groupement(ged_gr_nume) = 'PARIS'  then 1 else 0 end) as "Paris",
sum(case when fs_groupement(ged_gr_nume) = 'INTERGREFFE'  then 1 else 0 end) as "Intergreffe",
sum(case when fs_groupement(ged_gr_nume) = 'TI / TMC'  then 1 else 0 end) as "Tribunal Judiciaire"
from e_ged_lot gl
 join e_ged_document gd on gd.ged_lot_id = gl.gel_lot_id

where 1 = 1
-- and gl.gel_trait_fin_d > trunc(sysdate)
and  gl.gel_trait_debut_d >  to_date(  to_char(sysdate - 4 ,'dd/mm/yyyy') || ' 08:00:00' , 'dd/mm/yyyy hh24:MI:SS')
and GEL_NOMLOT not like'%RET%'
and ged_doctyp_c != 'JUDICIAIRE'
group by -- gd.ged_diff_c,
(case when ged_doctyp_c = 'ACTE'  then 'Acte'
      when ged_doctyp_c = 'LIASSEART3'  then 'Liasseart3'
     --when ged_doctyp_c = 'JUDICIAIRE'  then 'Judiciaire'
     Else 'Bilan'

  end )
 -- order by 1
union all
select --gd.ged_diff_c, /* gd.ged_erreur_c, */
'Judiciaire' as "Documents",

sum(case when fs_groupement_jud(ged_gr_nume) = 'Inf. Informatique' /*DEDALE*/  then 1 else 0 end) as "infogreffe",
sum(case when fs_groupement_jud(ged_gr_nume) = 'AGORA'  then 1 else 0 end) as "Agora",
sum(case when fs_groupement_jud(ged_gr_nume) = 'NOUVELLE-CALEDONIE'  then 1 else 0 end) as "Nouméa",
sum(case when fs_groupement_jud(ged_gr_nume) = 'MYGREFFE'  then 1 else 0 end) "MyGreffe" ,
sum(case when fs_groupement_jud(ged_gr_nume) = 'GAGI'  then 1 else 0 end) as "GAGI",
sum(case when fs_groupement_jud(ged_gr_nume) = 'PARIS'  then 1 else 0 end) as "Paris",
sum(case when fs_groupement_jud(ged_gr_nume) = 'INTERGREFFE'  then 1 else 0 end) as "Intergreffe",
sum(case when fs_groupement_jud(ged_gr_nume) = 'TI / TMC'  then 1 else 0 end) as "Tribunal Judiciaire"
from e_ged_lot gl
join e_ged_document gd on gd.ged_lot_id = gl.gel_lot_id   and ged_doctyp_c != 'LIASSEART3'

where 1 = 1
-- and gl.gel_trait_fin_d > trunc(sysdate)
and  gl.gel_trait_debut_d >  to_date(  to_char(sysdate - 4 ,'dd/mm/yyyy') || ' 08:00:00' , 'dd/mm/yyyy hh24:MI:SS')
and GEL_NOMLOT not like'%RET%'
and ged_doctyp_c = 'JUDICIAIRE'
;

