select
sum(case when to_char(est_exec_fin_d,   'HH24:MI:SS')  <= '08:00:00'  then 1 else 0 end ) as "OK",
sum(case when to_char(est_exec_fin_d,   'HH24:MI:SS')  > '08:00:00'  or (est_exec_fin_d is null) then 1 else 0 end ) as "KO",
sum(1) as "total"
from e_surv_tracage
where est_trait_client not like 'K%'
and est_trait_nom  = 'IPMULTIREV1.sh'
and est_trait_d > (select to_date(gpt_val, 'DD/MM/YYYY') from g_parm_trait where GPT_RD_C = 'COM' and  GPT_CP_C      = 'D_DATE_TRT')
