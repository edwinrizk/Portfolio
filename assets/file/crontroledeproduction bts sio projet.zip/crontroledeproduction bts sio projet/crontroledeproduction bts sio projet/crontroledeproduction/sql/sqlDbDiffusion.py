import cx_Oracle
import configparser
import datetime
import sqlite3
import email





def getLstRejetJud(env_app):

    res = select_sql_file(file='sqlrejetjud.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getDateFraicheurSerpent(env_app):

    res = select_sql_file(file='sqlDateFraicheurSerpent.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getDateFraicheurXML(env_app):

    res = select_sql_file(file='sqlDateFraicheurXML.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getCentralisationXML(env_app):

    res = select_sql_file(file='sqlCentralisationXml.sql', con=env_app.getcnxDiff(), fields=None)
    return res


def getGedNbDocGrp(env_app):

    res = select_sql_file(file='sqlGedNbDocGrp.sql', con=env_app.getcnxDiff(), fields=None)
    return res


def getGedNbGreffeManquant(env_app):

    res = select_sql_file(file='sqlNbGreffeManquantGed.sql', con=env_app.getcnxDiff(), fields=None)
    print(res)
#    res1 = select_sql_file(file='sqlNbGreffeManquantGedJUD.sql', con=env_app.getcnxDiff(), fields=None)
#    print(res1)
    return res

def getLstGedGreffeManquant(env_app):

    res = select_sql_file(file='sqlListeGreffeGedManquant.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getCtrlIpMono(env_app):

    res = select_sql_file(file='ControleIpMono.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getCtrlIpMulti(env_app):

    res = select_sql_file(file='ControleIpMulti.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getCtrlIpKyc(env_app):

    res = select_sql_file(file='ControleIpKyc.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getCLtIpMultiKO(env_app,):
    tab=[]
    res=[]
    sql=select_sql_file(file='ClientIP_Multi_KO.sql', con=env_app.getcnxDiff(), fields=None)
    for i in range (len(sql)):
        tab.append(sql[i][0])
    if len(tab) != 0:
        strtab = "\n".join(tab)
        res.append(strtab)
        return res
    else:
        return tab


def getCLtIpMonoKO(env_app):
    tab = []
    res = []
    sql = select_sql_file(file='ClientIP_Mono_KO.sql', con=env_app.getcnxDiff(), fields=None)
    for i in range(len(sql)):
        tab.append(sql[i][0])
    if len(tab) != 0:
        strtab = "\n".join(tab)
        res.append(strtab)
        return res
    else:
        return tab


def getCLtIpKYCKO(env_app):
    tab = []
    res = []
    sql = select_sql_file(file='ClientIP_KYC_KO.sql', con=env_app.getcnxDiff(), fields=None)
    for i in range(len(sql)):
        tab.append(sql[i][0])
    if len(tab) != 0:
        strtab = "\n".join(tab)
        res.append(strtab)
        return res
    else:
        return tab


def getRtdCtrlIpMulti(env_app):
    res = select_sql_file(file='RtdControleIpMulti.sql', con=env_app.getcnxDiff(), fields=None)
    return res

def getRtdCtrlIpMono(env_app):
    res = select_sql_file(file='RtdControleIpMono.sql',con=env_app.getcnxDiff(),fields=None)
    return res

def getRtdCtrlIpKYC(env_app):
    res = select_sql_file(file='RtdControleIpKYC.sql',con=env_app.getcnxDiff(),fields=None)
    return res

def getLstRtdMulti(env_app):
    tab = []
    res = []
    sql = select_sql_file(file='LstRtdClientMulti.sql',con=env_app.getcnxDiff(),fields=None)
    for i in range(len(sql)):
        tab.append(sql[i][0])
    if len(tab) != 0:
        strtab = "\n".join(tab)
        res.append(strtab)
        return res
    else:
        return tab


def getLstRtdMono(env_app):
    tab = []
    res = []
    sql = select_sql_file(file='LstRtdClientMono.sql',con=env_app.getcnxDiff(),fields=None)
    for i in range(len(sql)):
        tab.append(sql[i][0])
    if len(tab) != 0:
        strtab = "\n".join(tab)
        res.append(strtab)
        return res
    else:
        return tab

def getLstRtdKYC(env_app):
    tab = []
    res = []
    sql = select_sql_file(file='LstRtdClientKYC.sql',con=env_app.getcnxDiff(),fields=None)
    for i in range(len(sql)):
        tab.append(sql[i][0])
    if len(tab) != 0:
        strtab = "\n".join(tab)
        res.append(strtab)
        return res
    else:
        return tab

def getNbDocGEDerreur(env_app):
    res = select_sql_file(file='sqlNbdocumentserreurGED.sql',con=env_app.getcnxDiff(),fields=None)
    return res

def getNbGEDsansreponse(env_app):
    res = select_sql_file(file='sqlNbGEDsansreponse.sql', con=env_app.getcnxDiff(), fields=None)
    return res
def RejetsXMLRCS_NonRegularises(env_app):
    res =select_sql_file(file='sqlRejetsXMLRCS_NonRegularises.sql',con=env_app.getcnxDiff(), fields=None)
    return res

def getNbRejetsTechniqueNonEncoreRegularises(env_app):
    res = select_sql_file(file='sqlNbRejetsTechniqueNonEncoreRégularisés.sql',con=env_app.getcnxDiff(),fields=None)
    return res

def getDocumentGEDnonCentralise(env_app):
    res = select_sql_file(file='DocumentGEDnonCentralisé.sql',con=env_app.getcnxDiff(),fields=None)
    return res

def getNbrejetRCSnonregularise(env_app):
    res=select_sql_file(file='sqlNbrejetRCSnonregularise.sql',con=env_app.getcnxDiff(),fields=None)
    return res
def getNbbeneficiaireeffectifdoublesurdoss(env_app):
    res= select_sql_file(file='Nbbeneffectifdoubledoss.sql',con=env_app.getcnxDiff(),fields=None)
    return res

def getupdaterejetjud(env_app):
    res= select_sql_files(file='updaterejetjud.sql',con=env_app.getcnxJud())
    return res

def getMajDate(env_app):
    res= select_sql_files(file='updatemajdate.sql',con=env_app.getcnxDiff())
    return res
def getListeGreffelLiassesManquant3DernierJours(env_app):
    tab = []
    res = []
    sql=select_sql_file(file='sqlListeGreffelLiassesManquant3DernierJours.sql',con=env_app.getcnxDiff(),fields=None)
    for i in range(len(sql)):
        tab.append(sql[i][0])
    if len(tab) != 0:
        strtab = "\n ".join(tab)
        res.append(strtab)
        return res
    else:
        return tab
def getListeGreffelLiassesManquant3DernierJours2(env_app):
    tab = []
    res = []
    sql = select_sql_file(file='sqlListeGreffelLiassesManquant3DernierJours.sql', con=env_app.getcnxDiff(), fields=None)
    for i in range(len(sql)):
        tab.append(sql[i][1])
    if len(tab) != 0:
        strtab = "\n ".join(tab)
        res.append(strtab)
        return res
    else:
        return tab

def getcontrol_ip(env_app, send_email=None):
    try:
        # Mis à jours de l'indexation SQLite

        d = datetime.datetime.now()
        d = d.replace(hour=0, minute=0, second=0, microsecond=0)
        config = configparser.RawConfigParser()

        config.read('./config/app.properties')
        con = create_connection(env_app, "./config/app.properties")

        batch_multi_name = config.get('batch', 'batch.multi_name')
        traitement_multi = select_sql_file('selectControleIpMulti.sql', con, (d,batch_multi_name))

        batch_mono_name = config.get('batch', 'batch.mono_name')
        batch_mono_type = config.get('batch', 'batch.mono_out_type')
        traitement_mono = select_sql_file('selectControleIpMono.sql', con, (d, batch_mono_name, batch_mono_type))

        batch_kyc_name = config.get('batch', 'batch.kyc_name')
        batch_kyc_type = config.get('batch', 'batch.kyc_out_type')
        traitement_kyc = select_sql_file('selectControleIpKyc.sql', con, (d, batch_kyc_name, batch_kyc_type))
        send_email.email_control_ip(env_app, traitement_multi, traitement_mono, traitement_kyc)


    except cx_Oracle.DatabaseError as dbError:
        print(dbError)
        return False
    except Exception as error:
        print(error)
        return False
    return True

"""
requete sql
"""
def select_sql_file(file, con, fields):
    try:
        c = con.cursor()
        sql = open_file(file)

        sql_instructions = sql.split(';')

        for instruction in sql_instructions:
            if fields is None:
                c.execute(instruction)
            else:
                c.execute(instruction, fields)

            crest = c.fetchall()
            c.close()
            return crest

    except cx_Oracle.OperationalError as opError:
        print("Command ignored ", opError)
"""
update sql
"""
def select_sql_files(file, con):
    try:
        c = con.cursor()
        sql = open_file(file)

        sql_instructions = sql.split(';')

        for instruction in sql_instructions:
                c.execute(instruction)


        con.commit()
        c.close()
            #return crest

    except cx_Oracle.OperationalError as opError:
        print("Command ignored ", opError)


def start1(env_app):
    return getcontrol_ip(env_app)

def open_file(file):
    try:
        f = open("./sql/" + file, 'r')
        data = f.read()
        f.close()
        return data

    except FileNotFoundError as fnfError:
        print(fnfError)


def create_connection(env_app,base):
    strcnx=''
    if base =='JUD':
        strcnx = env_app.get_cnxJudOracle()
    elif base == 'DIFF':
        strcnx = env_app.get_cnxDiffOracle()

    conn = cx_Oracle.connect(strcnx)
    return conn

