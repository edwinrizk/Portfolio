select to_char(gl.gel_trait_debut_d, 'DD/MM/YYYY') as "Date réception lot",
--Inf. Informatique
sum(case when (
(ged_doctyp_c <> 'JUDICIAIRE' and fs_groupement(ged_gr_nume) = 'Inf. Informatique' )
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'Inf. Informatique' )
) then 1 else 0 end) as "infogreffe",
-- Agora
sum (case  when (
(ged_doctyp_c <> 'JUDICIAIRE'  and fs_groupement(ged_gr_nume) = 'AGORA' )
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'AGORA'  )
) then 1 else 0 end) as "Agora" ,
--Nouméa
sum(case when (
(ged_doctyp_c <> 'JUDICIAIRE'  and fs_groupement(ged_gr_nume) = 'NOUVELLE-CALEDONIE' )
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'NOUVELLE-CALEDONIE')
) then 1 else 0 end) as "Nouméa",
--MyGreffe
sum(case when (
(ged_doctyp_c <> 'JUDICIAIRE' and fs_groupement(ged_gr_nume) = 'MYGREFFE' )
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'MYGREFFE')
) then 1 else 0 end) "MyGreffe" ,
--GAGI
sum(case when (
(ged_doctyp_c <> 'JUDICIAIRE'  and fs_groupement(ged_gr_nume) = 'GAGI'  )
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'GAGI' )
) then 1 else 0 end) as "GAGI",
--Paris
sum(case when (
(ged_doctyp_c <> 'JUDICIAIRE' and fs_groupement(ged_gr_nume) = 'PARIS' )
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'PARIS' )
) then 1 else 0 end) as "Paris",
--Intergreffe
sum(case when (
(ged_doctyp_c <> 'JUDICIAIRE' and fs_groupement(ged_gr_nume) = 'INTERGREFFE')
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'INTERGREFFE' )
) then 1 else 0 end) as "Intergreffe",
--Tribunal Judiciaire
sum(case when (
(ged_doctyp_c <> 'JUDICIAIRE' and fs_groupement(ged_gr_nume) = 'TI / TMC'  )
or
(ged_doctyp_c = 'JUDICIAIRE' and fs_groupement_jud(ged_gr_nume) = 'TI / TMC'  )
) then 1 else 0 end) as "Tribunal Judiciaire"
--

from e_ged_lot gl
join e_ged_document gd on gd.ged_lot_id = gl.gel_lot_id
where 1 = 1
and  trunc(gl.gel_trait_debut_d) >=  trunc(sysdate -18)
and  trunc(gl.gel_trait_debut_d) <  trunc(sysdate )
--and GEL_NOMLOT not like'%RET%'
and GED_TRAIT_AR_D  is null
and gd.ged_doctyp_c not  in ('LIASSEART3')
and gd.ged_diff_c not in ('KO_NEW','KO_SUPPR')
group by to_char(gl.gel_trait_debut_d, 'DD/MM/YYYY')
order by to_date("Date réception lot", 'DD/MM/YYYY' );