select est_trait_d,
        est_trait_client,
        est_trait_domaine,
        est_trait_periode,
        est_exec_fin_d,
        est_trait_ok_ko
from e_surv_tracage
where est_trait_d = :1
and est_trait_nom = :2
order by est_trait_client
;