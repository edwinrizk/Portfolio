select      CER_ELEMENT_VALEUR as "Erreur"    , count(*) as "Nombre" , min(to_char(a.CED_creat_D,'DD/MM/YYYY')) as "Date min", max(to_char(a.CED_creat_D,'DD/MM/YYYY'))as "Date max"

from e_cent_dossier a,    e_cent_ctrl_err , e_cent_reg_gestion
where 1=1
-- en rejet
and nvl(a.CED_SUPPRIME_ON, '0') = '0'
and a.ced_etat_c = 'KO'
and  cer_dos_id = a.ced_dos_id
and cer_rg_c  in ( 'RG999')
and CER_BLOQUANT_ON = '1'
and crg_rg_c = cer_rg_c
-- non  suivi d'une autre transmission
and not exists
(select 1 from e_cent_dossier b
where a.CED_GR_NUME    = b.CED_GR_NUME
and a.CED_DO_MIL       = b.CED_DO_MIL
and a.CED_DO_ST_C      = b.CED_DO_ST_C
and a.CED_DO_CHRONO    = b.CED_DO_CHRONO
and b.CED_creat_D  > a.CED_creat_D
)

--
group by CER_RG_C     ,CRG_RG_L,  CER_ELEMENT_VALEUR
order by count(*) desc ;