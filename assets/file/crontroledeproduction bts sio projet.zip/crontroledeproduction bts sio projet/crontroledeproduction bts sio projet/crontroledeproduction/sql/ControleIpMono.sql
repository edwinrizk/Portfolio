select
sum(case when est_trait_ok_ko = 'OK'  then 1 else 0 end ) as "OK",
sum(case when est_trait_ok_ko = 'KO'  then 1 else 0 end ) as "KO",
sum(1) as "total"
from e_surv_tracage
where est_trait_client not like 'K%'
and est_trait_client != 'NATIXIS'
and est_trait_nom = 'IPMONOREV0001.sh'
and est_trait_d > (select to_date(gpt_val, 'DD/MM/YYYY') from g_parm_trait where GPT_RD_C = 'COM' and  GPT_CP_C      = 'D_DATE_TRT');