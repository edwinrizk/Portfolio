select 'PN',gr_gp_nume, gp_l, AC_EF_GR_NUME,gr_nom , AF_EF_AC_MAJ_D
from a_act_effectuees, e_greffe, e_groupement
where AC_EF_GR_NUME in (select gr_nume from e_greffe where fs_verif_greffe_ouvert (gr_nume, null, null) = 1)
and AC_EF_GR_NUME = gr_nume
and gr_gp_nume = gp_nume
and af_ef_ac_c = '03'
and (gr_gp_nume in ('02', '05', '03','51') or gr_nume = '7501')
and af_ef_ac_fraicheur is not null
and -- af_ef_ac_fraicheur
        AF_EF_AC_MAJ_D < (select to_date(gpt_val, 'DD/MM/YYYY HH24:MI:SS') from g_parm_trait where gpt_cp_c like 'D_DATE_TRT')
order by gr_gp_nume, af_ef_ac_fraicheur
;