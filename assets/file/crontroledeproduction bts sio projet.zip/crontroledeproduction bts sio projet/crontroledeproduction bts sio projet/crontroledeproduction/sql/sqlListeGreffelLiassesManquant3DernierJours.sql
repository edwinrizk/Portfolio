select   gr_nume||'  '|| gr_nom, to_char(max(GLI_ORAD_D),'DD/MM/YYYY') from e_rda_liasse , e_greffe
where  gli_gr_nume = gr_nume
and gr_gp_nume = '03'
group by gr_nume, gr_nom
having  max(GLI_ORAD_D) < (select to_date(gpt_val, 'DD/MM/YYYY') -3   from g_parm_trait where gpt_cp_c = 'D_DATE_TRT' )
order by max(GLI_ORAD_D)