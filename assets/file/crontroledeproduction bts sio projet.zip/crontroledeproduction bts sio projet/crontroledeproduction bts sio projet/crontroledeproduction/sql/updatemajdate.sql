delete a_act_effectuees a
where 1 = 1
and a.af_ef_ac_c in ('90' ,'50','60','30','40');

insert into a_act_effectuees t (ac_ef_gr_nume, af_ef_ac_c, af_ef_ac_fraicheur )
( select gr_nume, '90', max(ced_creat_d) - 21/24 --to_char( max(ced_creat_d),'dd/mm/yyyy')
from e_greffe, e_cent_dossier
where gr_nume = ced_gr_nume
and fs_verif_greffe_ouvert(gr_nume, null, null) = 1
and ced_do_st_c <> 'F'
and gr_nume not in
(
select ced_gr_nume
from e_cent_dossier
where ced_gr_nume in (
select gr_nume from e_greffe where fs_verif_greffe_ouvert(gr_nume, null, null) = 1 )
and ced_do_st_c <> 'F'
and ced_creat_d >= (select to_date(gpt_val, 'DD/MM/YYYY HH24:MI:SS') + 21/24 from g_parm_trait where gpt_cp_c = 'D_DATE_TRT' )
and ced_creat_d < (select to_date(gpt_val, 'DD/MM/YYYY') + 2 from g_parm_trait where gpt_cp_c = 'D_DATE_TRT' )
)
group by gr_gp_nume, gr_nume, gr_nom
);

insert into a_act_effectuees t (ac_ef_gr_nume, af_ef_ac_c, af_ef_ac_fraicheur )
( select ac_ef_gr_nume, '60',af_ef_ac_fraicheur
   from a_act_effectuees p
   where 1 = 1
   and p.af_ef_ac_c = '90'
   and not exists(select 1 from a_act_effectuees q where q.ac_ef_gr_nume = p.ac_ef_gr_nume and q.af_ef_ac_c = '60')
)

;
insert into a_act_effectuees t (ac_ef_gr_nume, af_ef_ac_c, af_ef_ac_fraicheur )
( select ac_ef_gr_nume, '50',af_ef_ac_fraicheur
   from a_act_effectuees p
   where 1 = 1
   and p.af_ef_ac_c = '90'
   and not exists(select 1 from a_act_effectuees q where q.ac_ef_gr_nume = p.ac_ef_gr_nume and q.af_ef_ac_c = '50')
)

;
insert into a_act_effectuees t (ac_ef_gr_nume, af_ef_ac_c, af_ef_ac_fraicheur )
( select ac_ef_gr_nume, '30',af_ef_ac_fraicheur
   from a_act_effectuees p
   where 1 = 1
   and p.af_ef_ac_c = '90'
   and not exists(select 1 from a_act_effectuees q where q.ac_ef_gr_nume = p.ac_ef_gr_nume and q.af_ef_ac_c = '30')
)
;
insert into a_act_effectuees t (ac_ef_gr_nume, af_ef_ac_c, af_ef_ac_fraicheur )
( select ac_ef_gr_nume, '40',af_ef_ac_fraicheur
   from a_act_effectuees p
   where 1 = 1
   and p.af_ef_ac_c = '90'
   and not exists(select 1 from a_act_effectuees q where q.ac_ef_gr_nume = p.ac_ef_gr_nume and q.af_ef_ac_c = '40')
);
delete a_act_effectuees a
where  1 = 1
and a.af_ef_ac_c  in ('08', '27', '28');

insert into a_act_effectuees t (ac_ef_gr_nume, af_ef_ac_c, af_ef_ac_fraicheur, AF_EF_AC_MAJ_D )
( select ac_ef_gr_nume, '08', af_ef_ac_fraicheur, AF_EF_AC_MAJ_D
   from a_act_effectuees p
   where 1 = 1
   and p.af_ef_ac_c = '01'
   and not exists(select 1 from a_act_effectuees q where q.ac_ef_gr_nume = p.ac_ef_gr_nume and q.af_ef_ac_c = '08')
);

insert into a_act_effectuees t (ac_ef_gr_nume, af_ef_ac_c, af_ef_ac_fraicheur, AF_EF_AC_MAJ_D )
( select ac_ef_gr_nume, '27', af_ef_ac_fraicheur, AF_EF_AC_MAJ_D
   from a_act_effectuees p
   where 1 = 1
   and p.af_ef_ac_c = '01'
   and not exists(select 1 from a_act_effectuees q where q.ac_ef_gr_nume = p.ac_ef_gr_nume and q.af_ef_ac_c = '27')
)
