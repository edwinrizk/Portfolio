select * from
    (

        select 'JUDICIAIRE', gr_gp_Lib, count(1) as nbgrf
        from
            ( select distinct nvl(fs_groupement_jud(gr_nume), 'TI / TMC') as gr_gp_Lib,
                              gr_nume as gr_nume,
                              'JUDICIAIRE'  as Document
              from e_greffe
              where 1 = 1
                and fs_verif_greffe_ouvert(gr_nume, '01 02 03 05 20 51 40 ', null) = 1
                and gr_nume ||'JUDICIAIRE'
                  not in (select distinct
                                  gd.ged_gr_nume || gd.ged_doctyp_c  as Documents
                          from e_ged_lot gl
                                   join e_ged_document gd on gd.ged_lot_id = gl.gel_lot_id   and gd.ged_doctyp_c = 'JUDICIAIRE'
                          where 1 = 1

                            and  gl.gel_trait_debut_d >  to_date(  to_char(sysdate - 4 ,'dd/mm/yyyy') || ' 08:00:00' , 'dd/mm/yyyy hh24:MI:SS')
                    )

            )
        group by gr_gp_lib


        order by 2,1
    )
        pivot (sum(nbgrf) for gr_gp_lib in ('Inf. Informatique','AGORA','NOUVELLE-CALEDONIE' ,'MYGREFFE' ,'GAGI','PARIS','INTERGREFFE','TI / TMC') )
order by 1;