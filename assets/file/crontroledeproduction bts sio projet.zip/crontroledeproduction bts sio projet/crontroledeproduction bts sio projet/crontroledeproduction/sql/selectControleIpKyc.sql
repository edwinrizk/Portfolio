select est_trait_d as Date_du_traitement,
        case when est_trait_client = 'KBA' then 'BATICA' else
        case when est_trait_client = 'KB' then 'BPCE' else
        case when est_trait_client = 'KH' then 'HSBC' else
        case when est_trait_client = 'KLA' then 'LATELIER' else est_trait_client
        end end end end,
    est_trait_domaine,
    est_trait_periode,
    est_exec_fin_d,
    est_trait_ok_ko
from E_SURV_TRACAGE
where est_trait_d = :1
and est_trait_nom = :2
and est_output_type <> :3
order by est_trait_client;