select * from
    (

        select document, gr_gp_Lib, count(1) as nbgrf from
            ( select distinct fs_groupement(gr_nume) as gr_gp_Lib,
                              gr_nume as gr_nume,
                              case when gdt.gdt_doctyp_c in ('BILAN', 'COMPTE_RES', 'DECL_CF_CR', 'DECL_CONF') then 'BILAN'
                                   else gdt.gdt_doctyp_c end as Document
              from e_greffe
                       join e_ged_doctype gdt on gdt.gdt_doctyp_c in
                                                 ( 'BILAN','COMPTE_RES','DECL_CF_CR','DECL_CONF', 'ACTE','BILAN','LIASSEART3' ) --,'JUDICIAIRE')
              where 1 = 1
                and fs_verif_greffe_ouvert(gr_nume, '01 02 03 05 20 51 40 ', null) = 1
                and gr_nume ||
                    case when gdt.gdt_doctyp_c in ('BILAN', 'COMPTE_RES', 'DECL_CF_CR', 'DECL_CONF') then 'BILAN'
                         else gdt.gdt_doctyp_c end
                  not in (select distinct
                                  gd.ged_gr_nume ||
                                  (case when gd.ged_doctyp_c in ('BILAN', 'COMPTE_RES', 'DECL_CF_CR', 'DECL_CONF') then 'BILAN'
                                        else gd.ged_doctyp_c end ) as Documents
                          from e_ged_lot gl
                                   join e_ged_document gd on gd.ged_lot_id = gl.gel_lot_id
                          where 1 = 1
                            and  gl.gel_trait_debut_d >  to_date(  to_char(sysdate - 4 ,'dd/mm/yyyy') || ' 08:00:00' , 'dd/mm/yyyy hh24:MI:SS')
                    )

              union
              select distinct nvl(fs_groupement_jud(gr_nume), 'TI / TMC') as gr_gp_Lib,
                              gr_nume as gr_nume,
                              'JUDICIAIRE'  as Document
              from e_greffe
              where 1 = 1
                and fs_verif_greffe_ouvert(gr_nume, '01 02 03 05 20 51 40 ', null) = 1
                and gr_nume ||'JUDICIAIRE'
                  not in (select distinct
                                  gd.ged_gr_nume || gd.ged_doctyp_c  as Documents
                          from e_ged_lot gl
                                   join e_ged_document gd on gd.ged_lot_id = gl.gel_lot_id   and gd.ged_doctyp_c = 'JUDICIAIRE'
                          where 1 = 1

                            and  gl.gel_trait_debut_d >  to_date(  to_char(sysdate - 4 ,'dd/mm/yyyy') || ' 08:00:00' , 'dd/mm/yyyy hh24:MI:SS')
                    )

                -- order by 3,1,2
            )
        group by document,gr_gp_lib


    )
        pivot (sum(nbgrf) for gr_gp_lib in ('Inf. Informatique','AGORA','NOUVELLE-CALEDONIE' ,'MYGREFFE' ,'GAGI','PARIS','INTERGREFFE','TI / TMC') )
order by 1;