import argparse
import datetime



from scripts import create_db, extractdatactrldb, generateHtml, dataforrepport
from scripts.courriel import courriel
from utils import ctrlprodenv
from sql import sqlDbDiffusion

if __name__ == "__main__" :

    print("Main ")
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', help='DataBase  ([init], [back])')
    parser.add_argument('--reedition' , help='mode réédition mail (:) [Yes] , [No] par defaut :No  ')
    args = parser.parse_args()

#    env_app = ctrlprodenv.Env()
    print(args.reedition)

    if args.db == 'init':
        #Création de la base de donnée
        env_app = ctrlprodenv.Env("NO")
        create_db.init(env_app)
    if args.reedition == 'Yes':
        env_app = ctrlprodenv.Env('yes')
        meteo = dataforrepport.start(env_app)
    else:
        env_app = ctrlprodenv.Env("NO")
        extractdatactrldb.startctrl(env_app)
        meteo = dataforrepport.start(env_app)
        ip = sqlDbDiffusion.start1(env_app)


    cour = courriel(env_app)
    """ 
    htmlagora =generateHtml.start(env_app,meteo, 'MYGREFFE')
    fileres = open('testHtmlAgora.html','w')
    fileres.write(htmlagora)
    cour.sendCourrielWin32MyGreffe(htmlagora)
    """
    htmlInfg = generateHtml.start(env_app,meteo, 'INFG')
    cour.sendCourrielWin32Inf(htmlInfg)
    fileres = open('test.html','w')
    fileres.write(htmlInfg)
    """
    htmlBackof = generateHtml.start(env_app,meteo,'')
    cour.sendCourrielWin3backoffice(htmlBackof)
    fileres=open('testHTMLBackoffice.html','w')
    fileres.write(htmlBackof)
    """