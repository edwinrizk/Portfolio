import math

from sql import sqlDbCtrl, sqlDbDiffusion
from utils import ctrlprodobj, ctrlprodobjnew


def extractdatameteo(env_app):
    meteo = ctrlprodobjnew.Meteo()
    db = env_app.get_pathdb() + env_app.get_dbname()

    idtrt = sqlDbCtrl.getIdTrt(db)

    print("db : ", db)
    print("idtrt : ", idtrt)
    meteo.set_idtrt(idtrt)

    """ 
       Récupération des rejets judiciaires
    """
    lst = sqlDbCtrl.get_ErreurJudiciaire(db=db, paramidtrt=idtrt, type='MyGreffe')
    meteo.set_ctrljudiciaireMyGreffe(lst)

    lst = sqlDbCtrl.get_ErreurJudiciaire(db=db, paramidtrt=idtrt, type='INF')
    meteo.set_ctrljudiciaireInf(lst)



    """ 
      Centralisation RCS XML OK - KO et Calcul du % d'erreur 
    """
    lst = sqlDbCtrl.get_CompteurCentralRcsXml(db=db, paramidtrt=idtrt)

    lst1 = ["% d'erreur","0.00%", "0.00%", "0.00%", "0.00%", "0.00%", "0.00%", "0.00%"]
    print(lst)
    for i in range(7):
        print(lst[0][i+1])
        if lst[0][i+1] != None :
            if (lst[0][i + 1] > 0):

                lst1[i + 1] = str((round((lst[1][i + 1] / lst[0][i + 1]) * 100, 2))) + " %"
            else:
                lst1[i + 1] = "0.00 %"
    lst.insert(2, lst1)

    meteo.set_ctrlCompteurCentralisation(lst)

    """ 
        Date de fraîcheur P&N et XML
    """
    lst = sqlDbCtrl.get_lstAllDateFraicheur(db=db, paramidtrt=idtrt)
    meteo.set_ctrlDateFraicheurInf(lst)

    lst = sqlDbCtrl.get_lstMyGreffeDateFraicheur(db=db, paramidtrt=idtrt)
    meteo.set_ctrlDateFraicheurMyGreffe(lst)

    """
      Centralisation Geide
    """

    lst = sqlDbCtrl.get_CompteurGeideAllGrp(db=db, paramidtrt=idtrt, type="DOC_GEIDE")
    meteo.set_ctrlcptgednbdocInf(lst)

    lst = sqlDbCtrl.get_CompteurGeideMyGreffe(db=db, paramidtrt=idtrt, type="DOC_GEIDE")
    meteo.set_ctrlcptgednbdocMyGreffe(lst)

    lst = sqlDbCtrl.get_CompteurGeideAllGrp(db=db, paramidtrt=idtrt, type="GRF_MANQ")
    meteo.set_ctrlcptgednbgrfoutInf(lst)

    lst = sqlDbCtrl.get_CompteurGeideMyGreffe(db=db, paramidtrt=idtrt, type="GRF_MANQ")
    meteo.set_ctrlcptgednbgrfoutMyGreffe(lst)

    lst = sqlDbCtrl.get_LstGrfGeideOutAllGrp(db=db, paramidtrt=idtrt)
    meteo.set_ctrllstgrfoutInf(lst)
    print(meteo.get_ctrllstgrfoutInf())

    lst = sqlDbCtrl.get_LstGrfGeideOutMyGreffe(db=db, paramidtrt=idtrt)
    meteo.set_ctrllstgrfoutMyGreffe(lst)

    """
        IP OK/KO
    """
    """
    lst = sqlDbDiffusion.getCtrlIpMulti(env_app)
    meteo.set_CtrlIpMulti(lst)

    lst = sqlDbDiffusion.getCtrlIpMono(env_app)
    meteo.set_CtrlIpMono(lst)

    lst = sqlDbDiffusion.getCtrlIpKyc(env_app)
    meteo.set_CtrlIpKyc(lst)

    
    Liste client KO
    """
    """
    lst = sqlDbDiffusion.getCLtIpMultiKO(env_app)
    meteo.set_cltKoMulti(lst)

    lst = sqlDbDiffusion.getCLtIpMonoKO(env_app)
    meteo.set_cltKoMono(lst)

    lst = sqlDbDiffusion.getCLtIpKYCKO(env_app)
    meteo.set_cltKoKYC(lst)

    
    Retard Controle Ip 
    """
    """
    lst = sqlDbDiffusion.getRtdCtrlIpMulti(env_app)
    meteo.set_RtdCtrlIpMulti(lst)

    lst = sqlDbDiffusion.getRtdCtrlIpMono(env_app)
    meteo.set_RtdCtrlIpMono(lst)

    lst = sqlDbDiffusion.getRtdCtrlIpKYC(env_app)
    meteo.set_RtdCtrlIpKyc(lst)


    Liste des retards Ip
    """
   # lst = sqlDbDiffusion.getLstRtdMulti(env_app)
    #meteo.set_LstRtdMulti(lst)

    #lst = sqlDbDiffusion.getLstRtdMono(env_app)
    #meteo.set_LstRtdMono(lst)

   # lst =sqlDbDiffusion.getLstRtdKYC(env_app)
   # meteo.set_LstRtdKYC(lst)
    """
    Nombre de Document GED en erreur
    """
#    lst = sqlDbDiffusion.getNbDocGEDerreur(env_app)
 #   meteo.set_NbDocGEDerreur(lst)

    """
    GED sans Réponse
    """
  #  lst=sqlDbDiffusion.getNbGEDsansreponse(env_app)
   # meteo.set_NbGEDsansreponse(lst)

    """
    Rejets XML/RCS non Régularisés
    """
    #lst=sqlDbDiffusion.RejetsXMLRCS_NonRegularises(env_app)
    #meteo.set_RejetsXMLRCS_NonRegularises(lst)
    """
    Nb Rejets Technique Non Encore Régularisés
    """
   # lst=sqlDbDiffusion.getNbRejetsTechniqueNonEncoreRegularises(env_app)
    #meteo.set_NbRejetsTechniqueNonEncoreRegularises(lst)

    """
    Documents GED Non Centralisés
    """

    #lst=sqlDbDiffusion.getDocumentGEDnonCentralise(env_app)
    #meteo.set_DocumentGEDnonCentralise(lst)

    """
    Nombre de rejets RCS non encore régularisés
    """

    #lst=sqlDbDiffusion.getNbrejetRCSnonregularise(env_app)
    #meteo.set_NbrejetRCSnonregularise(lst)

    """
    Nombre de bénéficiaires effectifs en doubles sur le dossier
    """

    #lst = sqlDbDiffusion.getNbbeneficiaireeffectifdoublesurdoss(env_app)
    #meteo.set_Nbbeneficiaireeffectifdoublesurdoss(lst)

    """
    Update rejet judiciaire et maj Date
    """

    #sqlDbDiffusion.getupdaterejetjud(env_app)

    #sqlDbDiffusion.getMajDate(env_app)

    """
    Liste greffe liasses manquant 3dernier jours
    """
    #lst=sqlDbDiffusion.getListeGreffelLiassesManquant3DernierJours(env_app)
    #meteo.set_ListeGreffelLiassesManquant3DernierJours(lst)

    #lst = sqlDbDiffusion.getListeGreffelLiassesManquant3DernierJours2(env_app)
    #meteo.set_ListeGreffelLiassesManquant3DernierJours2(lst)

    """
        Synthese
    """
    lstSynthese = []

    """
    lstTemp = ("Infogreffe inf.", "None","None",0,0,"None","None")
    lstSynthese.insert(0,lstTemp)
    lstTemp = ("AGORA", "None","None",0,0,"None","None")
    lstSynthese.insert(1,lstTemp)
    lstTemp = ("MyGreffe", 0,0,0,0,0,0)
    lstSynthese.insert(2,lstTemp)
    lstTemp = ("Nouméa", 0,0,0,0,0,0)
    lstSynthese.insert(3,lstTemp)
    lstTemp = ("TI-TMC", 0,0,0,0,0,0)
    lstSynthese.insert(4,lstTemp)
    lstTemp = ("PARIS", 0,0,0,0,0,0)
    lstSynthese.insert(5,lstTemp)
    lstTemp = ("GAGI", 0,0,0,0,0,0)
    lstSynthese.insert(6,lstTemp)
    lstTemp = ("INTERGREFFE", 0,0,0,0,0,0)
    lstSynthese.insert(7,lstTemp)
    """

    print( meteo.get_ctrlcptgednbgrfoutInf())
    for grp in ['Inf. Informatique', 'AGORA', 'MYGREFFE', 'NOUMEA','Tribunal Judiciaire','PARIS','GAGI', 'INTERGREFFE'] :  #'TI - TMC',
        print (grp)
        lstTemp = ()
        lstTemp = lstTemp + (grp,)

        """
            Privilège et Nantissement Inf. Informatique et Agora deviennent MyGreffe
        """
        print (meteo.get_ctrlDateFraicheurInf())
        if (grp in ['Inf. Informatique', 'AGORA' ]) :
            lstTemp = lstTemp +( 'None',)
        else:
            t1 = [ ligne[2] for ligne in meteo.get_ctrlDateFraicheurInf() if ligne[0] == grp and ligne[1] == 'PN' ]
            cpt = 0
            print(t1)
            if len(t1) > 0:
                for grf in t1[0].split("\n") :
                    cpt  +=1
            print(cpt)

            if grp =='MYGREFFE':
                lstTemp = lstTemp + ( math.ceil(100 * cpt/89),)
                 #idx = 4
            elif grp == 'NOUMEA':
                lstTemp = lstTemp + ( math.ceil( 100 * cpt / 1 ),)
                #idx = 3
            elif ( grp == 'Tribunal Judiciaire') :
                lstTemp = lstTemp + ( math.ceil(100 *cpt / 7) ,)
                #idx = 5
            elif grp == 'PARIS':
                lstTemp = lstTemp + ( math.ceil(100 * cpt / 1 ), )
                #idx = 7
            elif grp == 'GAGI' :
                lstTemp = lstTemp + ( math.ceil(100 * cpt / 20 ),)
                #idx = 6
            else :                 #grp =='INTERGREFFE':
                lstTemp = lstTemp + (math.ceil( 100 * cpt / 31 ),)
                #idx = 8

            print(len(t1))
            print(lstTemp)
        """
            RCS  Inf. Informatique et Agora deviennent MyGreffe
        """
        if (grp in ['Inf. Informatique', 'AGORA' ]) :
            lstTemp = lstTemp + ('None',)
        else:
            t1 = [ ligne[2] for ligne in meteo.get_ctrlDateFraicheurInf() if ligne[0] == grp and ligne[1] == 'RCS' ]
            #  lstTemp = lstTemp +(len(t1),)
            cpt = 0


            if len(t1) > 0:
                for grf in t1[0].split("\n") :
                    cpt +=1
                print(cpt)

            if grp =='MYGREFFE':
                lstTemp = lstTemp + ( math.ceil(100 *  cpt/89),)
                #idx = 4
            elif grp == 'NOUMEA':
                lstTemp = lstTemp + ( math.ceil( 100 *  cpt / 1 ),)

                #idx = 3
            elif grp  == 'Tribunal Judiciaire':
                lstTemp = lstTemp + ( math.ceil(100 *  cpt / 7) ,)
                #idx = 5
            elif grp == 'PARIS':
                lstTemp = lstTemp + ( math.ceil(100 *  cpt / 1 ), )
                #idx = 7
            elif grp == 'GAGI' :
                lstTemp = lstTemp + ( math.ceil(100 *  cpt / 20 ),)
                #idx = 6
            else :                 #grp =='INTERGREFFE':
                lstTemp = lstTemp + (math.ceil( 100 *  cpt / 31 ),)
                #idx = 8
            #print(len(t1))
            #print(lstTemp)
        """
            Judiciaire
        """
        if grp == 'Inf. Informatique':
            grpNume = '01'
        elif grp == 'AGORA':
            grpNume = '05'
        elif grp =='MYGREFFE':
            grpNume = '03'
        elif grp == 'NOUMEA':
            grpNume = '40'
        elif grp == 'Tribunal Judiciaire':
            grpNume = '20'
        elif grp == 'PARIS':
            grpNume = '75'
        elif grp == 'GAGI' :
            grpNume = '02'
        elif grp =='INTERGREFFE':
            grpNume = '51'

        t1 = [ligne[0] for ligne in meteo.get_ctrljudiciaireInf() if ligne[4] == grpNume]
        if grp == 'NOUMEA' :
            lstTemp = lstTemp + ('None',)
        elif grp == 'MYGREFFE' :
            lstTemp = lstTemp + ('None',)
        elif grp == 'Tribunal Judiciaire' :
            lstTemp = lstTemp + ('None',)
        else:
            lstTemp = lstTemp + (len(t1),)


        """ 
            GEIDE [('ACTE', 0, 0, 0, 0, 0, 0, 0, 1, 4), ('BILAN', 0, 0, 0, 1, 1, 0, 0, 0, 5), ('JUDICIAIRE', 0, 1, 1, 0, 7, 2, 0, 3, 6), ]
            Ifnull(INFOGREFFE,0), 
            Ifnull(AGORA,0), 
            Ifnull(NOUMEA,0) ,
             Ifnull(MYGREFFE,0),  Ifnull(TITMC,0),Ifnull(GAGI,0), Ifnull(PARIS,0), Ifnull(INTERGREFFE ,0), chrono
        """
        lstTmp = meteo.get_ctrlcptgednbgrfoutInf()[:]
        print( lstTmp)
        lst.clear()

        myidx = 0

        if lstTmp[myidx][0] == 'ACTE':

            lst.append(lstTmp[myidx])

            myidx = myidx + 1

        else:

            lst.append(('ACTE', 0, 0, 0, 0, 0, 0, 0, 0, 0))

        if lstTmp[myidx][0] == 'BILAN':

            lst.append(lstTmp[myidx], )

            myidx = myidx + 1

        else:

            lst.append(('BILAN', 0, 0, 0, 0, 0, 0, 0, 0, 1))

        if lstTmp[myidx][0] == 'JUDICIAIRE':

            lst.append(lstTmp[myidx], )

            myidx = myidx + 1

        else:

            lst.append(('JUDICIAIRE', 0, 0, 0, 0, 0, 0, 0, 0, 2))

        if lstTmp[myidx][0] == 'LIASSEART3':

            lst.append(lstTmp[myidx])

            myidx = myidx + 1

        else:

            lst.append(('LIASSEART3', 0, 0, 0, 0, 0, 0, 0, 0, 3))


        if grp == 'Inf. Informatique':
            lstTemp = lstTemp + ('None','None',lst[1][1],'None')
            # idx = 1
        elif grp == 'AGORA':
            lstTemp = lstTemp + ('None','None',lst[2][2],'None')
            idx = 2
        elif grp =='MYGREFFE':
            lstTemp = lstTemp + ( math.ceil(100 * lst [0][4]/89), math.ceil(100 * lst[1][4] /89) ,'None',math.ceil(100 * lst[3][4] /89))
           #idx = 4
        elif grp == 'NOUMEA':
            lstTemp = lstTemp + ( math.ceil( 100 * lst [0][3] / 1 ) , math.ceil(100 *lst[1][3] / 1) ,'None',math.ceil(100 *lst[1][3] / 1)) # math.ceil(100 *lst [2][3] / 1) ,)
            #idx = 3
        elif grp == 'Tribunal Judiciaire':
            lstTemp = lstTemp + ( math.ceil(100 * lst [0][5] / 7) , math.ceil(100 *lst[1][5] / 7) ,'None', math.ceil(100 *lst[3][5] / 7)) # math.ceil(100 *lst [2][5] / 7) ,)
            #idx = 5
        elif grp == 'PARIS':
            lstTemp = lstTemp + ( math.ceil(100 * lst [0][7] / 1 ), math.ceil(100 *lst[1][7] / 1) , math.ceil(100 *lst [2][7] / 1 ),math.ceil(100 *lst [3][7] / 1 ))
            #idx = 7
        elif grp == 'GAGI' :
            lstTemp = lstTemp + ( math.ceil(100 * lst [0][6] / 20 ), math.ceil(100 *lst[1][6] / 20) , math.ceil(100 *lst [2][6]/ 20),math.ceil(100 *lst [3][6]/ 20))
            #idx = 6
        else :                 #grp =='INTERGREFFE':
            lstTemp = lstTemp + (math.ceil( 100 * lst [0][8] / 31 ), math.ceil(100 *lst[1][8] / 31) , math.ceil(100 *lst [2][8] / 31), math.ceil(100 *lst [3][8] / 31))
            #idx = 8
        print(meteo.get_ctrlcptgednbgrfoutInf())



        print(lst)

        lstSynthese.append(lstTemp)
    print(lstSynthese)
    meteo.set_synthese(lstSynthese)
    return meteo


def start(env_app):
    return extractdatameteo(env_app)

