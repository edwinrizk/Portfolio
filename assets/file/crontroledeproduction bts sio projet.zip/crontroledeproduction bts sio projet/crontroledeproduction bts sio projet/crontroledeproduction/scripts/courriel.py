import os
import pathlib

from win32com.client import Dispatch
from utils import ctrlprodenv

class courriel:
    """
        Class défénissant un courriel
        - emetteur
        - destinataire(s)
        - copy à <<cc>>
        - destinataire invisible << cci >>
        - l'object du messages
        - pièce jointe
        - corps du messages

    """

    def __init__(self,  env_app):
        """
            Constructeur de la classe
        """
        self.__from = env_app.get_emailsender()
        self.__to = env_app.get_emailreceiver()
        self.__subject = ""
        self.__body = ""
        outlook = Dispatch('outlook.application')
        self.mail = outlook.CreateItem(0)

    def set_subjetct(self, title):
        self._subject = title

    def sendCourrielWin32MyGreffe(self,html):
        outlook = Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.To = 'edwin.rizk@docaposte.fr'
        mail.Subject = self.__subject
        mail.Body = html
        mail.HTMLBody = html
        mail.Send()

    def sendCourrielWin32Inf(self,html ):
        outlook = Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.To = 'edwin.rizk@docaposte.fr'
        mail.Subject = self.__subject
        mail.Body = html
        mail.HTMLBody = html
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(),"assets\img\meteo\\") + "Soleil1.png")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(),"assets\img\meteo\\") + "nuage_light.jpg")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(),"assets\img\meteo\\") + "nuage1.png")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(),"assets\img\meteo\\") + "nuage_pluie.png")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(),"assets\img\meteo\\") + "orage2.png")

        mail.Send()

    def sendCourrielWin3backoffice(self,html):
        outlook = Dispatch('outlook.application')
        mail = outlook.CreateItem(0)
        mail.To = 'edwin.rizk@docaposte.fr'
        mail.Subject = self.__subject
        mail.Body = html
        mail.HTMLBody = html
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(), "assets\img\meteo\\") + "Soleil1.png")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(), "assets\img\meteo\\") + "nuage_light.jpg")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(), "assets\img\meteo\\") + "nuage1.png")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(), "assets\img\meteo\\") + "nuage_pluie.png")
        mail.Attachments.Add(os.path.join(pathlib.Path().absolute(), "assets\img\meteo\\") + "orage2.png")
        mail.Send()

