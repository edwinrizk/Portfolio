import datetime
import locale
import os
import pathlib
import base64

from os.path import abspath

from jinja2 import Environment, FileSystemLoader


def generateRepportAgora(env_app, meteo):
    lstrubrique = []
    locale.setlocale(locale.LC_TIME, "fr_FR")
    # On récupère le template AGORA

    env = Environment()
    env.loader = FileSystemLoader('./view/templates')

    htmlAgora = env.get_template("repportMygreffe.html")

    # récupère la date du jour
    datenow = datetime.datetime.now()
    mydatenow = datenow.strftime('%A %d.%m.%Y')
    # Verification si ajout rubrique mensuelle
    if datenow.day == '01':
        lstrubrique.append('Mensuelle')
    if len(meteo.get_ctrljudiciaireMyGreffe()) > 0 :
        lstrubrique.append('RejetJud')
    if len(meteo.get_ctrlDateFraicheurMyGreffe()) >0 :
        lstrubrique.append('DateFraicheur')
    lstrubrique.append('CentralData')
    lstrubrique.append('Geide')
    print(lstrubrique)
    meteo.toString()
    return htmlAgora.render(date=mydatenow, lstRubrique=lstrubrique, meteo=meteo)


def generateRepportInfg(env_app, meteo):

    lstrubrique = []
    locale.setlocale(locale.LC_TIME, "fr_FR")
    # On récupère le template infogreffe

    env = Environment()
    env.loader = FileSystemLoader('./view/templates')
    html = env.get_template("repportInfg.html")

    pathImage = os.path.join(pathlib.Path().absolute(),"assets\img\meteo\\")
    print(pathImage)
    # récupère la date du jour
    datenow = datetime.datetime.now()
    mydatenow = datenow.strftime('%A %d.%m.%Y')

    if (meteo.get_ctrljudiciaireInf() ) :
        lstrubrique.append('RejetJud')

    if (meteo.get_ctrlDateFraicheurInf() ) :
        lstrubrique.append('DateFraicheur')

    return html.render(date=mydatenow, lstRubrique=lstrubrique, meteo=meteo  )

def generateRepportingBackoffice(env_app,meteo):
    lstrubrique = []
    locale.setlocale(locale.LC_TIME, "fr_FR")
    # On récupère le template backoffice

    env = Environment()
    env.loader = FileSystemLoader('./view/templates')
    html2 = env.get_template("repportbackoffice.html")

    # récupère la date du jour
    datenow = datetime.datetime.now()
    mydatenow = datenow.strftime('%A %d.%m.%Y')

    if (meteo.get_ctrljudiciaireInf()):
        lstrubrique.append('RejetJud')

    if (meteo.get_ctrlDateFraicheurInf()):
        lstrubrique.append('DateFraicheur')

    return html2.render(date=mydatenow, lstRubrique=lstrubrique, meteo=meteo)


def start(env_app, meteo, typeRepport):
    print("Génération de l'HTML")
    # HTML pour AGORA MYgreffe et diffusion

    if typeRepport == 'MYGREFFE':
        html = generateRepportAgora(env_app, meteo)
    elif typeRepport == 'INFG':
        html = generateRepportInfg(env_app, meteo)
    else:
        html = generateRepportingBackoffice(env_app, meteo)


    return html
