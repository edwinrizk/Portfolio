from sql import sqlDbCtrl
from utils import ctrlprodobj


def extractdatameteo(env_app):
    meteo = ctrlprodobj.Meteo()
    db = env_app.get_pathdb() + env_app.get_dbname()

    idtrt = sqlDbCtrl.getIdTrt(db)
    print("db : ", db)
    print("idtrt : ", idtrt)
    meteo.set_idtrt(idtrt)

    """ 
        Date de fraîcheur P&N et XML
    """
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='PN', greffe_groupe_num='03')
    meteo.set_reportingPN_DF_Mygreffe(lst)
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='RCS', greffe_groupe_num='03')
    meteo.set_reportingRCS_DF_Mygreffe(lst)

    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='PN', greffe_groupe_num='40')
    meteo.set_reportingPN_DF_Noumea(lst)
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='RCS', greffe_groupe_num='40')
    meteo.set_reportingRCS_DF_Noumea(lst)

    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='PN', greffe_groupe_num='05')
    meteo.set_reportingPN_DF_Agora(lst)
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='RCS', greffe_groupe_num='05')
    meteo.set_reportingRCS_DF_Agora(lst)

    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='PN', greffe_groupe_num='20')
    meteo.set_reportingPN_DF_TITMC(lst)
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='RCS', greffe_groupe_num='20')
    meteo.set_reportingRCS_DF_TITMC(lst)

    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='PN', greffe_groupe_num='02')
    meteo.set_reportingPN_DF_Gagi(lst)
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='RCS', greffe_groupe_num='02')
    meteo.set_reportingRCS_DF_Gagi(lst)

    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='PN', greffe_groupe_num='51')
    meteo.set_reportingPN_DF_Intergreffe(lst)
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='RCS', greffe_groupe_num='51')
    meteo.set_reportingRCS_DF_Intergreffe(lst)

    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='PN', greffe_groupe_num='01')
    meteo.set_reportingPN_DF_Paris(lst)
    lst = sqlDbCtrl.get_lstDateFraicheur(db=db, paramidtrt='36', domaine='RCS', greffe_groupe_num='01')
    meteo.set_reportingRCS_DF_Paris(lst)





    print(lst)

    """ 
        Récupération des rejets judiciaires
    """
    lst = sqlDbCtrl.get_ErreurJudiciaire(db=db, paramidtrt=idtrt)
    print(lst)
    meteo.set_ctrljudiciaire(lst)

    """ 
        Centralisation RCS XML OK - KO et Calcul du % d'erreur 
    """

    lst = sqlDbCtrl.get_CompteurCentralRcsXml(db=db, paramidtrt=idtrt)

    lst1 = ["% d'erreur","0.00%", "0.00%", "0.00%", "0.00%", "0.00%", "0.00%", "0.00%"]

    for i in range(7):

        if (lst[0][i + 1] > 0):
            print("lst[0][i + 1] : " + str(lst[0][i + 1]))
            lst1[i + 1] = str((round((lst[1][i + 1] / lst[0][i + 1]) * 100, 2))) + " %"
        else:
            lst1[i + 1] = "0.00 %"

    lst.insert(2, lst1)

    meteo.set_ctrlcptxmlokko(lst)

    """
        Centralisation Geide
    """
    meteo.set_ctrlcptgednbdoc(sqlDbCtrl.get_CompteurGeide(db=db, paramidtrt=idtrt, type="DOC_GEIDE"))

    meteo.set_ctrlcptgednbgrfout(sqlDbCtrl.get_CompteurGeide(db=db, paramidtrt=idtrt, type="GRF_MANQ"))

    meteo.set_ctrllstgrfout(sqlDbCtrl.get_LstGrfGeideOut(db=db, paramidtrt=idtrt))

    return meteo


def start(env_app):
    return extractdatameteo(env_app)
