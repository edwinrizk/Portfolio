import datetime
import sqlite3

from numpy.distutils.fcompiler import none

import utils.ctrlprodobj


def insertinto_trt(sqlite_connection, ctrlobj):
    data = (ctrlobj.get_idtrt(), ctrlobj.get_datetrt(), ctrlobj.get_datetrtshort())
    sqlite_connection.execute('''INSERT INTO dashboard_traitement (idtrt ,date_execution ,shortdate) 
                                    VALUES(?, ?, ?);''',
                              data)



def insertinto_rejetjud(sqlite_connection, ctrlobj):
    lst = ctrlobj.get_ctrljudiciaire()
    chrono = 0
    if len(lst) == 0:
        lst = [(' - ',  # Groupement code
                ' - ',  # Ancien groupement
                ' - ',  # Code Rejet
                ' - ',  # GR_NUME
                ' - ',  # GR_NAME
                datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0),
                ' - ',  # Libelle rejet
                ' - '  # NB Rejet
                )]
    for item in lst:
        chrono = chrono + 1
        data = (ctrlobj.get_idtrt(),
                chrono,
                str(item[3]),  # GR_NUME
                item[4],  # GR_NAME
                item[5].strftime("%d/%m/%Y"),
                item[6],  # Libelle rejet
                item[7],  # NB Rejet
                item[0],  # Groupement code
                item[1],  # Ancien groupement
                item[2]  # Code Rejet
                )

        sqlite_connection.execute('''INSERT INTO dashboard_ctrljud (
                idtrt , 
                chrono , 
                ctrljud_gr_nume , 
                ctrljud_gr_nom  , 
                ctrljud_daterejet ,
                ctrljud_libellerej, 
                ctrljud_nbrej  , 
                ctrljud_gr_gp  ,  
                ctrljud_gr_gp_old,
                ctrljud_coderejet  )
         VALUES (?,?,?,?,?,?,?,?,?,?);''', data)


def insertinto_compteurXml(sqlite_connection, ctrlobj):
    lst = ctrlobj.get_ctrlcptxmlokko()
    chrono = 0
    for item in lst:
        chrono = chrono + 1
        data = (ctrlobj.get_idtrt(),
                chrono,
                item[0],  # OK / KO le premier est le OK
                item[1],  # nb doc infogreffe informatique tjrs = 0
                item[2],  # AGORA
                item[3],  # NOUMEA
                item[4],  # MYGREFFE
                item[5],  # GAGI
                item[6],  # PARIS
                item[7]  # INTERGREFFE
                )

        sqlite_connection.execute('''INSERT INTO  dashboard_ctrlcentxml (
            idtrt ,
            chrono ,
            ctrlcentxml_type ,
            INFOGREFFE ,
            AGORA ,
            NOUMEA ,
            MYGREFFE ,
            GAGI ,
            PARIS ,
            INTERGREFFE ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ? );''', data)


def insertinto_compteurGeide(sqlite_connection, ctrlobj):
    lst = ctrlobj.get_ctrlcptnbdocgeide()
    chrono = 0
    for item in lst:
        chrono = chrono + 1
        data = (ctrlobj.get_idtrt(),
                chrono,
                'DOC_GEIDE',
                item[0],  # Document acte - bilan - judiciaire -Liassseart3
                item[1],  # nb doc infogreffe informatique tjrs = 0
                item[2],  # AGORA
                item[3],  # NOUMEA
                item[4],  # MYGREFFE
                item[5],  # GAGI
                item[6],  # PARIS
                item[7],  # INTERGREFFE
                item[8]  # TI / TMC
                )

        sqlite_connection.execute('''INSERT INTO  dashboard_ctrlgedcompteur (
                idtrt ,
                chrono ,
                type ,
                documents,
                INFOGREFFE ,
                AGORA ,
                NOUMEA ,
                MYGREFFE ,
                GAGI ,
                PARIS ,
                INTERGREFFE ,
                TITMC ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?);''', data)

    lst = ctrlobj.get_ctrlcptnbgreffegeidehs()
    for item in lst:
        chrono = chrono + 1
        data = (ctrlobj.get_idtrt(),
                chrono,
                'GRF_MANQ',
                item[0],  # Document acte - bilan - judiciaire - liassart3
                item[1],  # nb doc infogreffe informatique tjrs = 0
                item[2],  # AGORA
                item[3],  # NOUMEA
                item[4],  # MYGREFFE
                item[5],  # GAGI
                item[6],  # PARIS
                item[7],  # INTERGREFFE
                item[8]  # TI / TMC
                )

        sqlite_connection.execute('''INSERT INTO  dashboard_ctrlgedcompteur (
                idtrt ,
                chrono ,
                type ,
                documents,
                INFOGREFFE ,
                AGORA ,
                NOUMEA ,
                MYGREFFE ,
                GAGI ,
                PARIS ,
                INTERGREFFE,
                TITMC) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?);''', data)

def insertinto_listegreffeout_pn_rcs(sqlite_connection, ctrlobj):
    lst = ctrlobj.get_ctrlprivetnan()
    chrono = 0
    for item in lst:
        chrono = chrono + 1
        data = (ctrlobj.get_idtrt(),
                chrono,
                item[0],  # RCS / PN
                item[1],  # Groupement code
                item[2],  # Groupement libellé
                item[3],  # code greffe
                item[4],  # nom greffe
                item[5]  # date de fraîcheur
                )

        sqlite_connection.execute('''INSERT INTO   dashboard_ctrldatefraicheur (
                idtrt,
                chrono   ,
                domaine ,
                greffe_groupe_num ,
                greffe_groupe_nom ,
                greffe_num ,
                greffe_nom ,
                date_fraicheur ) VALUES(?, ?, ?, ?, ?, ?, ?, ?);''', data)

    lst = ctrlobj.get_ctrlxml()
    for item in lst:
        chrono = chrono + 1
        data = (ctrlobj.get_idtrt(),
                chrono,
                item[0],  # RCS / PN
                item[1],  # Groupement code
                item[2],  # Groupement libellé
                item[3],  # code greffe
                item[4],  # nom greffe
                item[5]  # date de fraîcheur
                )
        sqlite_connection.execute('''INSERT INTO  dashboard_ctrldatefraicheur (
                idtrt,
                chrono   ,
                domaine ,
                greffe_groupe_num ,
                greffe_groupe_nom ,
                greffe_num ,
                greffe_nom ,
                date_fraicheur ) VALUES(?, ?, ?, ?, ?, ?, ?, ?);''', data)

def insertinto_listegreffeout_geide(sqlite_connection, ctrlobj):
    lst = ctrlobj.get_ctrllstgrfout()
    print(lst)
    chrono = 0
    for item in lst:
        chrono = chrono +1
        data = (ctrlobj.get_idtrt(),
                chrono,
                item[0],  # type de doc
                item[1],  # lst grf Infoggreffe inf.
                item[4],  # lst grf Agora OK
                item[8], #  5],  # lst grf Nouméa
                item[6], #  7],  # lst grf MyGreffe
                item[7], #  8],  # lst grf TITMC
                item[2],  # lst grf GAGI OK
                item[3],  # lst grf Paris
                item[5], # 6],  # lst grf Integreffe
                )

        sqlite_connection.execute('''INSERT INTO  dashboard_ctrlgedlstgreffesmanquant (
                idtrt ,
                chrono ,
                Documents ,
                INFOGREFFE ,
                AGORA ,
                NOUMEA ,
                MYGREFFE ,
                TITMC , 
                GAGI ,
                PARIS ,
                INTERGREFFE) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?);''', data)




def persistedata(env_app, ctrlobj):
    global sqlite_connection
    try:
        # 1. connecte a la base sqlite meteo
        sqlite_connection = sqlite3.connect(env_app.get_pathdbmeto())
        print("Successfully Connected to SQLite")

        # 2. Insertion en base des valeurs
        # 2.1 Info de traitement
        insertinto_trt(sqlite_connection, ctrlobj)
        print("Id de traitement")
        # 2.2 Rejet judiciaire
        insertinto_rejetjud(sqlite_connection, ctrlobj)
        print("Insert Rejet Jud")

        # 2.3 Les compteurs
        # 2.3.1 Compteur XML OK / KO
        insertinto_compteurXml(sqlite_connection, ctrlobj)
        print("Insert Compteur XML")

        # 2.3.2 Compteur Geide
        insertinto_compteurGeide(sqlite_connection, ctrlobj)
        print("Insert Compteur Geide")

        # 3. Liste des greffes manquant
        # 3.1 Centralisation P&n - RCS
        insertinto_listegreffeout_pn_rcs(sqlite_connection, ctrlobj)
        print("Insert lst Grffes Manquant RCS & P&N")

        # 3.2 liste greffes Geide n yant pas centralisé de données depuis plus de 3j
        insertinto_listegreffeout_geide(sqlite_connection, ctrlobj)
        print("Insert lst Grffes Geide Manquant")

    except sqlite3.Error as error:
        print("Error sqlite :", error)
        sqlite_connection.rollback()
    finally:
        if sqlite_connection:
            sqlite_connection.commit()
            sqlite_connection.close()
            print("sqlite connection is closed")


