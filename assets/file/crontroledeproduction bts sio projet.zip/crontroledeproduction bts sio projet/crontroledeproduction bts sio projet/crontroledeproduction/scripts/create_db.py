import sqlite3
from os.path import isfile

from utils import ctrlprodenv


def init(env_app):
    print("création database sqllite3")

    # 1. je verifie si la base existe
    if not isfile(env_app.get_pathdbmeto()):
        print("Création de la nouvelle base de données : " + env_app.get_pathdbmeto())
        createtables(env_app.get_pathdbmeto())
    else:
        print("Backup de la base existante et on complete {TO DO} ")
        createtables(env_app.get_pathdbmeto())

def createtables(db):
    global sqlite_connection
    try:
        # Connetion
        sqlite_connection = sqlite3.connect(db)
        cursor = sqlite_connection.cursor()
        print("Successfully Connected to SQLite")
        # table date traitement
        sqlite_create_table_query = '''CREATE TABLE dashboard_traitement(
                                            idtrt INTEGER PRIMARY KEY,
                                            date_execution datetime NOT NULL,
                                            shortdate date NOT NULL
                                        ) '''
        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        print("SQLite table 'dashboard_traitement' created")

        #table ctrl judiciaire
        sqlite_create_table_query = '''CREATE TABLE dashboard_ctrljud(
                                            idtrt INTEGER NOT NULL,
                                            chrono INTEGER NOT NULL,
                                            ctrljud_gr_nume VARCHAR(4),
                                            ctrljud_gr_nom  VARCHAR(100),
                                            ctrljud_daterejet VARCHAR(8),
                                            ctrljud_libellerej VARCHAR(50),
                                            ctrljud_nbrej  INTEGER,
                                            ctrljud_gr_gp VARCHAR(10) ,
                                            ctrljud_gr_gp_old VARCHAR(10) ,
                                            ctrljud_coderejet VARCHAR(10),
                                            PRIMARY KEY( idtrt, chrono) 
                                    ) '''
        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        print("SQLite table 'dashboard_ctrljud' created")

        # Table controle flux XML
        sqlite_create_table_query = '''CREATE TABLE dashboard_ctrlcentxml (
                                            idtrt INTEGER NOT NULL,
                                            chrono INTEGER NOT NULL,
                                            ctrlcentxml_type VARCHAR(2),
                                            INFOGREFFE INTEGER,
                                            AGORA INTEGER,
                                            NOUMEA INTEGER,                                        
                                            MYGREFFE INTEGER,
                                            GAGI INTEGER,
                                            PARIS INTEGER,
                                            INTERGREFFE INTEGER,
                                            PRIMARY KEY( idtrt, chrono)
                                    ) '''
        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        print("SQLite table 'dashboard_ctrlcentxml' created")

        # Tables controle Ged
        sqlite_create_table_query = '''CREATE TABLE dashboard_ctrlgedcompteur (
                                            idtrt INTEGER NOT NULL,
                                            chrono INTEGER NOT NULL,
                                            type VARCHAR(10),
                                            Documents VARCHAR,
                                            INFOGREFFE INTEGER,
                                            AGORA INTEGER,
                                            NOUMEA INTEGER,                                        
                                            MYGREFFE INTEGER,
                                            GAGI INTEGER,
                                            PARIS INTEGER,
                                            INTERGREFFE INTEGER,
                                            TITMC INTEGER,
                                            PRIMARY KEY( idtrt, chrono)) '''
        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        print("SQLite table 'dashboard_ctrlgedlstgreffesmanquant' created")

        sqlite_create_table_query = '''CREATE TABLE dashboard_ctrlgedlstgreffesmanquant (
                                            idtrt INTEGER NOT NULL,
                                            chrono INTEGER NOT NULL,
                                            Documents VARCHAR,
                                            INFOGREFFE VARCHAR2,
                                            AGORA VARCHAR2,
                                            NOUMEA VARCHAR2,                                        
                                            MYGREFFE VARCHAR2,
                                            TITMC VARCHAR2,
                                            GAGI VARCHAR2,
                                            PARIS VARCHAR2,
                                            INTERGREFFE VARCHAR2,
                                            PRIMARY KEY( idtrt, chrono)) '''
        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        print("SQLite table 'dashboard_ctrlgedlstgreffesmanquant' created")

        sqlite_create_table_query = '''CREATE TABLE dashboard_ctrldatefraicheur (
                                        idtrt INTEGER NOT NULL,
                                        chrono INTEGER NOT NULL,
                                        domaine VARCHAR(3),
                                        greffe_groupe_num VARCHAR(2),
                                        greffe_groupe_nom VARCHAR(200),
                                        greffe_num VARCHAR(4),
                                        greffe_nom VARCHAR(200),
                                        date_fraicheur datetime,
                                        PRIMARY KEY( idtrt, chrono));'''

        cursor.execute(sqlite_create_table_query)
        sqlite_connection.commit()
        print("SQLite table 'dashboard_ctrldatefraicheur' created")
    except sqlite3.Error as error:
        print("Error while creating a sqlite table", error)
    finally:
        if (sqlite_connection):
            sqlite_connection.close()
            print("sqlite connection is closed")
