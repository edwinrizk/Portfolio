import datetime


from scripts import populatemeteo
from sql import sqlDbCtrl, sqlDbDiffusion
from utils import ctrlprodenv, ctrlprodobj


def getIdTrt(db):
    id = sqlDbCtrl.getIdTrt(db)
    return id


def getLstRejetJud(env_app):
    # On recupère les erreurs judiciaires sur la base JUD
    return sqlDbDiffusion.getLstRejetJud(env_app)

def getresultip(env):
    return sqlDbDiffusion.control_ip(env)


def getDateFraicheurPN(env_app):
    return sqlDbDiffusion.getDateFraicheurSerpent(env_app)


def getDateFraicheurXML(env_app):
    return sqlDbDiffusion.getDateFraicheurXML(env_app)


def getCentralisationXML(env_app):
    return sqlDbDiffusion.getCentralisationXML(env_app)


def getGedNbDocGrp(env_app):
    return sqlDbDiffusion.getGedNbDocGrp(env_app)


def getGedNbGreffeManquant(env_app):
    return sqlDbDiffusion.getGedNbGreffeManquant(env_app)


def getLstGedGreffeManquant(env_app):
    return sqlDbDiffusion.getLstGedGreffeManquant(env_app)


def getCtrlIpMono(env_app):
    return sqlDbDiffusion.getCtrlIpMono(env_app)

def getCtrlIpMulti(env_app):
    return sqlDbDiffusion.getCtrlIpMulti(env_app)

def getCtrlIpKyc(env_app):
    return sqlDbDiffusion.getCtrlIpKyc(env_app)

def getCLtIpMultiKO(env_app):

    return sqlDbDiffusion.getCLtIpMultiKO(env_app)

def getCLtIpMonoKO(env_app):
    return sqlDbDiffusion.getCLtIpMonoKO(env_app)

def getCLtIpKYCKO(env_app):
    return sqlDbDiffusion.getCLtIpKYCKO(env_app)

def getRtdCtrlIpMulti(env_app):
    return sqlDbDiffusion.getRtdCtrlIpMulti(env_app)

def getRtdCtrlIpMono(env_app):
    return sqlDbDiffusion.getRtdCtrlIpMono(env_app)

def getRtdCtrlIpKYC(env_app):
    return sqlDbDiffusion.getRtdCtrlIpKYC(env_app)

def getLstRtdMulti(env_app):
    return sqlDbDiffusion.getLstRtdMulti(env_app)

def getLstRtdMono(env_app):
    return sqlDbDiffusion.getLstRtdMono(env_app)

def getLstRtdKYC(env_app):
    return sqlDbDiffusion.getLstrtdKYC(env_app)

def getNbDocGEDerreur(env_app):
    return sqlDbDiffusion.getNbDocGEDerreur(env_app)

def getNbGEDsansreponse(env_app):
    return  sqlDbDiffusion.getNbGEDsansreponse(env_app)

def startctrl(env_app):
    lst = ()
    # création de l'object METEO
    meteo = ctrlprodobj.Meteo()

    # Récuperation de la date du jour
    dateTrt = datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')
    dateTrtSort = datetime.datetime.now().strftime('%d/%m/%Y')

    # Récupère l'id de traitement
    idTrt = getIdTrt(env_app.get_pathdb() + env_app.get_dbname())
    meteo.set_dateTrt(datetrt=dateTrt, datetrtshort=dateTrtSort, idtrt=idTrt +1 )
    # 1. Rejets Judiciaires (idtrt,env_app )
    print('Contrôle Rejet Judiciaire')
    meteo.set_ctrljudiciaire(getLstRejetJud(env_app))

    # 2. Date de fraîcheur
    # 2.1 Privilege ET Nantissement centralisation serpent
    print('Récupération : P&N ')
    meteo.set_ctrlprivetnan(getDateFraicheurPN(env_app))

    # 2.2 Centralisation XML
    print('Liste des greffes en retarde de centralisation XML')
    meteo.set_ctrlxml(getDateFraicheurXML(env_app))

    # 3 Compteurs
    # centralisation XML
    print('Compteur de centralisation XML OK & KO ')
    meteo.set_ctrlcptxmlokko(getCentralisationXML(env_app))

    print('Compteur nombre de doc ged par type et groupement')
    meteo.set_ctrlcptgednbdoc(getGedNbDocGrp(env_app))

    print('Nb de greffe n ayant pas transmis de doc')
    meteo.set_ctrlcptgednbgrfout(getGedNbGreffeManquant(env_app))

    print('Liste des greffes n ayant pas centralisée')
    meteo.set_ctrllstgrfout(getLstGedGreffeManquant(env_app))

    print('Ip OK/KO')
    meteo.set_CtrlIpMono(getCtrlIpMono(env_app))
    meteo.set_CtrlIpMulti(getCtrlIpMulti(env_app))
    meteo.set_CtrlIpKyc(getCtrlIpKyc(env_app))


    print("Client KO")
    meteo.set_cltKoMulti(getCLtIpMultiKO(env_app))
    meteo.set_cltKoMono(getCLtIpMonoKO(env_app))
    meteo.set_cltKoKYC(getCLtIpKYCKO(env_app))

    #persistance des données
    populatemeteo.persistedata(env_app, meteo)
    return meteo