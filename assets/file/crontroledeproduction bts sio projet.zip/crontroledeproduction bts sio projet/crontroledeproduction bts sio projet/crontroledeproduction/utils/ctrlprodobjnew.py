import base64
import os
import pathlib


class Meteo:

    def __init__(self):
        self.__datetrt = ''
        self.__datetrtshort = ''
        self.__idtrt = int()
        self.__ctrlJudiciaireMygreffe = []
        self.__ctrlJudiciaireInf = []

        self.__ctrlDateFraicheurInf = []
        self.__ctrlDateFraicheurMyGreffe = []

        self.__ctrlCompteurCentralisation = []

        self.__ctrlcptgednbdocInf = []
        self.__ctrlcptgednbgrfoutInf = []
        self.__ctrllstgrfoutInf = []

        self.__ctrlcptgednbdocMyGreffe =[]
        self.__ctrlcptgednbgrfoutMyGreffe = []
        self.__ctrllstgrfoutMyGreffe = []

        self.__CtrlIpMono = []
        self.__CtrlIpMulti = []
        self.__CtrlIpKyc = []

        self.__cltKoMulti = []
        self.__cltKoMono = []
        self.__cltKoKYC = []

        self.__RtdCtrlIpMono = []
        self.__RtdCtrlIpMulti = []
        self.__RtdCtrlIpKyc = []

        self.__LstRtdCMono = []
        self.__LstRtdMulti = []
        self.__LstRtdKyc = []

        self.__NbDocGEDerreur = []

        self.__NbGEdsansreponse= []

        self.__NbRejetsTechniqueNonEncoreRégularisés= []

        self.__synthese = []

        self.__lstImage = []




    def getLstImage(self):
        return self.__lstImage

    def set_idtrt(self, idtrt):
        self.__idtrt = idtrt

    def get_idtrt(self):
        return self.__idtrt

    def set_dateTrt(self, idtrt, datetrt, datetrtshort):
        self.__idtrt = idtrt
        self.__datetrt = datetrt
        self.__datetrtshort = datetrtshort

    def get_datetrt(self):
        return self.__datetrt

    def get_datetrtshort(self):
        return self.__datetrtshort

    def set_ctrljudiciaireInf(self, lst):
        if len(lst) > 0:
            self.__ctrlJudiciaireInf = lst.copy()

    def get_ctrljudiciaireInf(self):
        return self.__ctrlJudiciaireInf

    def set_ctrljudiciaireMyGreffe(self, lst):
        if len(lst) > 0:
            self.__ctrlJudiciaireMygreffe = lst.copy()

    def get_ctrljudiciaireMyGreffe(self):
        return self.__ctrlJudiciaireMygreffe

    def set_ctrlCompteurCentralisation(self, lst):
        if len(lst) > 0:
            self.__ctrlCompteurCentralisation = lst.copy()

    def get_ctrlCompteurCentralisation(self):
        return self.__ctrlCompteurCentralisation

    def set_ctrlDateFraicheurInf(self, lst):
        if len(lst) > 0:
            self.__ctrlDateFraicheurInf = lst.copy()

    def get_ctrlDateFraicheurInf(self):
        return self.__ctrlDateFraicheurInf

    def set_ctrlDateFraicheurMyGreffe(self, lst):
        if len(lst) > 0:
            self.__ctrlDateFraicheurMyGreffe = lst.copy()

    def get_ctrlDateFraicheurMyGreffe(self):
        return self.__ctrlDateFraicheurMyGreffe

    def set_ctrlcptgednbdocInf(self, lst):
        if len(lst) > 0:
            self.__ctrlcptgednbdocInf = lst.copy()

    def get_ctrlcptgednbdocInf(self):
        return self.__ctrlcptgednbdocInf

    def set_ctrlcptgednbgrfoutInf(self, lst):
        if len(lst) > 0:
            self.__ctrlcptgednbgrfoutInf = lst.copy()

    def get_ctrlcptgednbgrfoutInf(self):
        return self.__ctrlcptgednbgrfoutInf

    def set_ctrllstgrfoutInf(self, lst):
        if len(lst) > 0:
            self.__ctrllstgrfoutInf = lst.copy()

    def get_ctrllstgrfoutInf(self):
        return self.__ctrllstgrfoutInf

    def set_ctrlcptgednbdocMyGreffe(self, lst):
        if len(lst) >0:
            self.__ctrlcptgednbdocMyGreffe = lst.copy()
    def get_ctrlcptgednbdocMyGreffe(self):
        return self.__ctrlcptgednbdocMyGreffe

    def set_ctrlcptgednbgrfoutMyGreffe(self, lst):
        if len(lst) > 0:
            self.__ctrlcptgednbgrfoutMyGreffe = lst.copy()

    def get_ctrlcptgednbgrfoutMyGreffe(self):
        return self.__ctrlcptgednbgrfoutMyGreffe

    def set_ctrllstgrfoutMyGreffe(self, lst):
        if len(lst) > 0:
            self.__ctrllstgrfoutMyGreffe = lst.copy()

    def get_ctrllstgrfoutMyGreffe(self):
        return self.__ctrllstgrfoutMyGreffe

    def set_synthese (self, lst) :
        if len(lst) > 0:
            self.__synthese = lst.copy()

    def get_synthese (self) :
        return self.__synthese

    def set_CtrlIpMono(self, lst):
        self.__CtrlIpMono = lst.copy()

    def get_CtrlIpMono(self):
        return self.__CtrlIpMono

    def set_CtrlIpMulti(self, lst):
        self.__CtrlIpMulti = lst.copy()

    def get_CtrlIpMulti(self):
        return self.__CtrlIpMulti

    def set_CtrlIpKyc(self, lst):
        self.__CtrlIpKyc = lst.copy()

    def get_CtrlIpKyc(self):
        return self.__CtrlIpKyc


    def set_cltKoMulti(self,lst):
        self.__cltKoMulti = lst.copy()

    def get_cltKoMulti(self):
        return self.__cltKoMulti

    def set_cltKoMono(self,lst):
        self.__cltKoMono = lst.copy()

    def get_cltKoMono(self):
        return self.__cltKoMono

    def set_cltKoKYC(self,lst):
        self.__cltKoKYC = lst.copy()

    def get_cltKoKYC(self):
       return self.__cltKoKYC

    def set_RtdCtrlIpMono(self, lst):
        self.__RtdCtrlIpMono = lst.copy()

    def get_RtdCtrlIpMono(self):
        return self.__RtdCtrlIpMono

    def set_RtdCtrlIpMulti(self, lst):
        self.__RtdCtrlIpMulti = lst.copy()

    def get_RtdCtrlIpMulti(self):
        return self.__RtdCtrlIpMulti

    def set_RtdCtrlIpKyc(self, lst):
        self.__RtdCtrlIpKyc = lst.copy()

    def get_RtdCtrlIpKyc(self):
        return self.__RtdCtrlIpKyc

    def set_LstRtdMulti(self,lst):
        self.__LstRtdMulti = lst.copy()

    def get_lstRtdMulti(self):
        return self.__LstRtdMulti

    def set_LstRtdMono(self,lst):
        self.__LstRtdCMono = lst.copy()

    def get_LstRtdMono(self):
        return self.__LstRtdCMono

    def set_LstRtdKYC(self,lst):
        self.__LstRtdKyc = lst.copy()

    def get_LstRtdKYC(self):
        return self.__LstRtdKyc

    def set_NbDocGEDerreur(self,lst):
        self.__NbDocGEDerreur = lst.copy()

    def get_NbDocGEDerreur(self):
        return self.__NbDocGEDerreur

    def set_NbGEDsansreponse(self,lst):
        self.__NbGEdsansreponse = lst.copy()

    def get_NbGEDsansreponse(self):
        return self.__NbGEdsansreponse

    def set_NbRejetsTechniqueNonEncoreRegularises(self,lst):

        self.__NbRejetsTechniqueNonEncoreRegularises = lst.copy()

    def get_NbRejetsTechniqueNonEncoreRegularises(self):

        return self.__NbRejetsTechniqueNonEncoreRegularises

    def set_DocumentGEDnonCentralise(self,lst):
        self.__DocumentGEDnonCentralise =lst.copy()

    def get_DocumentGEDnonCentralise(self):
        return  self.__DocumentGEDnonCentralise

    def set_NbrejetRCSnonregularise(self,lst):
        self.__NbrejetRCSnonregularise =lst.copy()

    def get_NbrejetRCSnonregularise(self):
        return  self.__NbrejetRCSnonregularise

    def set_Nbbeneficiaireeffectifdoublesurdoss(self,lst):
        self.__Nbbeneficiaireeffectifdoublesurdoss =lst.copy()

    def get_Nbbeneficiaireeffectifdoublesurdoss(self):
        return  self.__Nbbeneficiaireeffectifdoublesurdoss

    def set_RejetsXMLRCS_NonRegularises(self,lst):
        self.__RejetsXMLRCS_NonRegularises = lst.copy()

    def get_RejetsXMLRCS_NonRegularises(self):
        return self.__RejetsXMLRCS_NonRegularises

    def set_updaterejetjud(self,lst):
        self.__updaterejetjud =lst.copy()

    def get_updaterejetjud(self):
        return self.__updaterejetjud

    def set_updateMajDate(self,lst):
        self.__updateMajDate = lst.copy()

    def get_updateMajDate(self):
        return self.__updateMajDate

    def set_ListeGreffelLiassesManquant3DernierJours(self,lst):
        self.__ListeGreffelLiassesManquant3DernierJours=lst.copy()

    def get_ListeGreffelLiassesManquant3DernierJours(self):
        return self.__ListeGreffelLiassesManquant3DernierJours

    def set_ListeGreffelLiassesManquant3DernierJours2(self,lst):
        self.__ListeGreffelLiassesManquant3DernierJours2=lst.copy()

    def get_ListeGreffelLiassesManquant3DernierJours2(self):
        return self.__ListeGreffelLiassesManquant3DernierJours2

    def toString(self):
        print('Info controle traitement numero :', self.__idtrt)
        print('Date de contrôle : ', self.__datetrt)

        print('Liste des rejets judiciaires pour GIE INFOGREFFE')
        if len(self.__ctrlJudiciaireInf) > 0:
            for item in self.__ctrlJudiciaireInf:
                print('\t', item)
        else:
            print('\t Pas de rejet')

        print('Liste des rejets judiciaires pour MyGreffe')
        if len(self.__ctrlJudiciaireMygreffe) > 0:
            for item in self.__ctrlJudiciaireMygreffe:
                print('\t', item)
        else:
            print('\t Pas de rejet')


        print('Compteur centralisation XML')
        for item in self.__ctrlCompteurCentralisation:
            print('\t', item)

        print('Compteur Centralisation Geide pour GIE INFOGREFFE')

        for item in self.__ctrlcptgednbdocInf:
            print('\t', item)

        for item in self.__ctrlcptgednbgrfoutInf:
            print('\t', item)



        print('Compteur Centralisation Geide pour MyGreffe')
        for item in self.__ctrlcptgednbdocMyGreffe:
           print('\t', item)

        for item in self.__ctrlcptgednbgrfoutMyGreffe:
           print('\t', item)



        print('Liste des rejets Centralisation de données pour GIE Infogreffe')
        if len(self.__ctrlDateFraicheurInf) > 0:
            for item in self.__ctrlDateFraicheurInf:
                print('\t', item)
        else:
            print('\t Pas de rejet')

        print('Liste des rejets Centralisation de données pour MyGreffe')
        if len(self.__ctrlDateFraicheurMyGreffe) > 0:
            for item in self.__ctrlDateFraicheurMyGreffe:
                print('\t', item)
        else:
            print('\t Pas de rejet')


        print("liste des greffes manquant GEIDE pour GIE Infogreffe")
        for item in self.__ctrllstgrfoutInf:
            print('\t',item)

        print("liste des greffes manquant GEIDE pour MyGreffe")
        for item in self.__ctrllstgrfoutMyGreffe:
            print('\t',item)

        print('Ip OK/KO')

        for item in self.__CtrlIpMulti:
            print('\t', item)

        for item in self.__CtrlIpMono:
            print('\t',item)


        for item in self.__CtrlIpKyc:
            print('\t',item)

        print("liste des clients KO")
        print("Multi")
        for item in self.__cltKoMulti:
            print(item)
        print("Mono")
        for item in self.__cltKoMono:
            print(item)
        print("KYC")
        for item in self.__cltKoKYC:
            print(item)

        print("retard Controle Ip")
        for item in self.__RtdCtrlIpMulti:
            print (item)

        for item in self.__RtdCtrlIpMono:
            print(item)
        for item in self.__RtdCtrlIpKyc:
            print(item)

        print("liste des retard Ip")
        for item in self.__LstRtdMulti:
            print(item)

        for item in self.__LstRtdCMono:
            print(item)
        for item in self.__LstRtdKyc:
            print(item)
