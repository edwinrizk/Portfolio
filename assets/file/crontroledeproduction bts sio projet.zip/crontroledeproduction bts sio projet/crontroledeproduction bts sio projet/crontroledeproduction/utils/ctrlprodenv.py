import configparser
import os
import cx_Oracle

class Env:
    def __init__(self,reedit):

        config = configparser.RawConfigParser()
        config.read("./config/app.properties")
        self.__pathApp = os.getcwd()
        self.__dbname = config.get('databasesqllite', 'database.dbname')
        self.__dbrep = config.get('databasesqllite', 'database.repertoire')

        self.__dbJud = config.get('databasejudprd', 'database.schema')
        self.__dbhostjud = config.get('databasejudprd', 'database.dbhost')
        self.__dbportjud = config.get('databasejudprd', 'database.port')
        self.__dbusrjud = config.get('databasejudprd', 'database.user')
        self.__dbpwdjud = config.get('databasejudprd', 'database.password')


        self.__dbDif = config.get('databasediffprd', 'database.schema')
        self.__dbhostdif = config.get('databasediffprd', 'database.dbhost')
        self.__dbportdif = config.get('databasediffprd', 'database.port')
        self.__dbusrdif = config.get('databasediffprd', 'database.user')
        self.__dbpwddif = config.get('databasediffprd', 'database.password')

        self.__batch_multi_name = config.get('batch', 'batch.multi_name')
        self.__batch_mono_name = config.get('batch', 'batch.mono_name')
        self.__batch_mono_type = config.get('batch', 'batch.mono_out_type')
        self.__batch_kyc_name = config.get('batch', 'batch.kyc_name')
        self.__batch_kyc_type = config.get('batch', 'batch.kyc_out_type')


        if reedit != 'yes' :

            self.__dbMeteo = config.get('databasesqllite', 'database.dbname')
            self.__dbmeteorep = config.get('databasesqllite', 'database.repertoire')
            



        self.__emailsmtp = config.get('email', 'email.smtp')
        self.__emailport = config.get('email', 'email.port')
        self.__emailsender = config.get('email', 'email.sender')
        self.__emailreceiver = config.get('email', 'email.receiver')





    def getcnxDiff(self):
        return self.__cnxDiff

    def getcnxJud(self):
        return self.__cnxJud

    def create_connection(self,base):
        strcnx=''
        if base =='JUD':
            strcnx = self.get_cnxJudOracle()
        elif base == 'DIFF':
            strcnx = self.get_cnxDiffOracle()

        conn = cx_Oracle.connect(strcnx)
        return conn

    def get_cnxJudOracle(self):
        return self.__dbusrjud + '/' + self.__dbpwdjud + '@' + self.__dbhostjud + \
               ':' + self.__dbportjud + '/' + self.__dbJud

    def get_cnxDiffOracle(self):
        return self.__dbusrdif + '/' + self.__dbpwddif + '@' + self.__dbhostdif + \
               ':' + self.__dbportdif + '/' + self.__dbDif

    def get_dbname(self):
        return self.__dbname

    def get_pathdb(self):
        return self.__pathApp + '\\' + self.__dbrep + '\\'

    def get_pathdbmeto(self):
        return '.\\' + self.__dbmeteorep + '\\' + self.__dbMeteo

    def get_emailsmtp(self):
        return self.__emailsmtp

    def get_emailport(self):
        self.__emailport

    def get_emailsender(self):
        self.__emailsender

    def get_emailreceiver(self):
        self.__emailreceiver

    def toString(self):
        print(self.__pathApp)
        print(self.__dbname)
        print(self.__dbrep)
