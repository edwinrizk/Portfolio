class Meteo:

    def __init__(self):
        self.__datetrt = ''
        self.__datetrtshort = ''
        self.__idtrt = int()
        self.__ctrljudiciaire = []
        self.__ctrlprivetnan = []
        self.__ctrlxml = []
        self.__ctrlcptxmlokko = []
        self.__ctrlcptgednbdoc = []
        self.__ctrlcptgednbgrfout = []
        self.__ctrllstgrfout = []

        self.__reportingPN_DF_Mygreffe = []
        self.__reportingRCS_DF_Mygreffe = []
        self.__reportingPN_DF_Agora = []
        self.__reportingRCS_DF_Agora = []
        self.__reportingPN_DF_Noumea = []
        self.__reportingRCS_DF_Noumea = []
        self.__reportingPN_DF_Gagi = []
        self.__reportingRCS_DF_Gagi = []
        self.__reportingPN_DF_Paris = []
        self.__reportingRCS_DF_Paris = []
        self.__reportingPN_DF_Intergreffe = []
        self.__reportingRCS_DF_Intergreffe = []
        self.__reportingPN_DF_TITMC = []
        self.__reportingRCS_DF_TITMC = []

        self.__strreportingPN_DF_Mygreffe = ""
        self.__strreportingRCS_DF_Mygreffe = ""
        self.__strreportingPN_DF_Agora = ""
        self.__strreportingRCS_DF_Agora = ""
        self.__strreportingPN_DF_Noumea = ""
        self.__strreportingRCS_DF_Noumea = ""
        self.__strreportingPN_DF_Gagi = ""
        self.__strreportingRCS_DF_Gagi = ""
        self.__strreportingPN_DF_Paris = ""
        self.__strreportingRCS_DF_Paris = ""
        self.__strreportingPN_DF_Intergreffe = ""
        self.__strreportingRCS_DF_Intergreffe = ""
        self.__strreportingPN_DF_TITMC = ""
        self.__strreportingRCS_DF_TITMC = ""
        self.__reportCentralisationPN_RCS = False

    def set_idtrt(self, idtrt):
        self.__idtrt = idtrt

    def set_dateTrt(self, idtrt, datetrt, datetrtshort):
        self.__idtrt = idtrt
        self.__datetrt = datetrt
        self.__datetrtshort = datetrtshort

    def set_ctrljudiciaire(self, lst):
        if len(lst) > 0:
            self.__ctrljudiciaire = lst.copy()

    def set_ctrlprivetnan(self, lst):
        self.__ctrlprivetnan = lst.copy()

    def set_ctrlxml(self, lst):
        self.__ctrlxml = lst.copy()

    def set_ctrlcptxmlokko(self, lst):
        self.__ctrlcptxmlokko = lst.copy()

    def set_ctrlcptgednbdoc(self, lst):
        self.__ctrlcptgednbdoc = lst.copy()

    def set_ctrlcptgednbgrfout(self, lst):
        self.__ctrlcptgednbgrfout = lst.copy()

    def set_ctrllstgrfout(self, lst):
        self.__ctrllstgrfout = lst.copy()

    def get_idtrt(self):
        return self.__idtrt

    def get_datetrt(self):
        return self.__datetrt

    def get_datetrtshort(self):
        return self.__datetrtshort

    def get_ctrljudiciaire(self):
        return self.__ctrljudiciaire

    def get_ctrlcptxmlokko(self):
        return self.__ctrlcptxmlokko

    def get_ctrlcptnbdocgeide(self):
        return self.__ctrlcptgednbdoc

    def get_ctrlcptnbgreffegeidehs(self):
        return self.__ctrlcptgednbgrfout

    def get_ctrlprivetnan(self):
        return self.__ctrlprivetnan

    def get_ctrlxml(self):
        return self.__ctrlxml

    def get_ctrllstgrfout(self):
        return self.__ctrllstgrfout


                     # reporting Mygreffe #


    def set_reportingPN_DF_Mygreffe(self, lst):
        self.__reportingPN_DF_Mygreffe = lst.copy()
        for item in lst:
            self.__strreportingPN_DF_Mygreffe = self.__strreportingPN_DF_Mygreffe

    def get_reportingPN_DF_Mygreffe(self):
        return self.__reportingPN_DF_Mygreffe
        # for item in lst:
        #self.__strreportingRCS_DF_Mygreffe=  self.__reportingRCS_DF_Mygreffe [0]

    def set_reportingRCS_DF_Mygreffe(self, lst):
        self.__reportingRCS_DF_Mygreffe = lst.copy()
        # for item in lst:
        # self.__strreportingRCS_DF_Mygreffe=  self.__reportingRCS_DF_Mygreffe [0]

    def get_reportingRCS_DF_Mygreffe(self):
        return self.__reportingRCS_DF_Mygreffe
        # for item in lst:
        #self.__strreportingRCS_DF_Mygreffe=  self.__reportingRCS_DF_Mygreffe [0]


                    # reporting Noumea #


    def set_reportingPN_DF_Noumea(self, lst):
        self.__reportingPN_DF_Noumea = lst.copy()
        for item in lst:
            self.__strreportingPN_DF_Noumea = self.__strreportingPN_DF_Noumea

    def get_reportingPN_DF_Noumea(self):
        return self.__reportingPN_DF_Noumea
        # for item in lst:
        # self.__strreportingPN_DF_Noumea=  self.__reportingPN_DF_Noumea [0]

    def set_reportingRCS_DF_Noumea(self, lst):
        self.__reportingRCS_DF_Noumea = lst.copy()
        # for item in lst:
        # self.__strreportingRCS_DF_Noumea=  self.__reportingRCS_DF_Noumea [0]

    def get_reportingRCS_DF_Noumea(self):
        return self.__reportingRCS_DF_Noumea
        # for item in lst:
        # self.__strreportingRCS_DF_Noumea=  self.__reportingRCS_DF_Noumea [0]


                     # reporting Agora  #

    def set_reportingPN_DF_Agora(self, lst):
        self.__reportingPN_DF_Agora = lst.copy()
        for item in lst:
            self.__strreportingPN_DF_Agora = self.__strreportingPN_DF_Agora


    def get_reportingPN_DF_Agora(self):
        return self.__reportingPN_DF_Agora
        # for item in lst:
        #self.__strreportingRCS_DF_Agora=  self.__reportingRCS_DF_Agora [0]

    def set_reportingRCS_DF_Agora(self, lst):
       self.__reportingRCS_DF_Agora= lst.copy()
       # for item in lst:
       #self.__strreportingRCS_DF_Agora=  self.__reportingRCS_DF_Agora [0]

    def get_reportingRCS_DF_Agora(self):
        return self.__reportingRCS_DF_Agora
        # for item in lst:
        #self.__strreportingRCS_DF_Agora=  self.__reportingRCS_DF_Agora [0]



                # REPORTING TI-TMC #


    def set_reportingPN_DF_TITMC(self, lst):
        self.__reportingPN_DF_TITMC= lst.copy()
        for item in lst:
            self.__strreportingPN_DF_TITMC=  self.__strreportingPN_DF_TITMC

    def get_reportingPN_DF_TITMC(self):
        return self.__reportingRCS_DF_TITMC

    def set_reportingRCS_DF_TITMC(self, lst):
       self.__reportingRCS_DF_TITMC= lst.copy()
       # for item in lst:
       #self.__strreportingRCS_DF_TITMC=  self.__reportingRCS_DF_TITMC [0]

    def get_reportingRCS_DF_TITMC(self):
        return self.__reportingRCS_DF_TITMC

                     # reporting Gagi  #


    def set_reportingPN_DF_Gagi(self, lst):
        self.__reportingPN_DF_Gagi= lst.copy()
        for item in lst:
            self.__strreportingPN_DF_Gagi=  self.__strreportingPN_DF_Gagi

    def get_reportingPN_DF_Gagi(self):
        return self.__reportingPN_DF_Gagi
        # for item in lst:
        #self.__strreportingPN_DF_Gagi=  self.__reportingPN_DF_Gagi [0]

    def set_reportingRCS_DF_Gagi(self, lst):
       self.__reportingRCS_DF_Gagi= lst.copy()
       # for item in lst:
       #self.__strreportingRCS_DF_Gagi=  self.__reportingRCS_DF_Gagi [0]

    def get_reportingRCS_DF_Gagi(self):
        return self.__reportingRCS_DF_Gagi
        # for item in lst:
        #self.__strreportingRCS_DF_Gagi=  self.__reportingRCS_DF_Gagi [0]



                     # reporting Intergreffe  #

    def set_reportingPN_DF_Intergreffe(self, lst):
        self.__reportingPN_DF_Intergreffe = lst.copy()
        for item in lst:
             self.__strreportingPN_DF_Intergreffe=  self.__strreportingPN_DF_Intergreffe

    def get_reportingPN_DF_Intergreffe(self):
        return self.__reportingPN_DF_Intergreffe

    def set_reportingRCS_DF_Intergreffe(self, lst):
        self.__reportingRCS_DF_Intergreffe= lst.copy()
       # for item in lst:
       #self.__strreportingRCS_DF_Intergreffe=  self.__reportingRCS_DF_Intergreffe [0]

    def get_reportingRCS_DF_Intergreffe(self):
        return self.__reportingRCS_DF_Intergreffe

                    # reporting Paris  #

    def set_reportingPN_DF_Paris(self, lst):
        self.__reportingPN_DF_Paris = lst.copy()
        for item in lst:
            self.__strreportingPN_DF_Paris=  self.__strreportingPN_DF_Paris

    def get_reportingPN_DF_Paris(self):
        return self.__reportingPN_DF_Paris

    def get_reportingRCS_DF_Paris(self):
        return self.__reportingRCS_DF_Paris

    def set_reportingRCS_DF_Paris(self, lst):
        self.__reportingRCS_DF_Paris = lst.copy()
        # for item in lst:
        # self.__strreportingRCS_DF_Paris=  self.__reportingRCS_DF_Paris [0]

    def set_reportCentralisationPN_RCS(self):
        self.__reportCentralisationPN_RCS = (
                len(self.__reportingPN_DF_Mygreffe) > 0 or
                len(self.__reportingRCS_DF_Mygreffe) > 0 or
                len(self.__reportingPN_DF_Agora) > 0 or
                len(self.__reportingRCS_DF_Agora) > 0 or
                len(self.__reportingPN_DF_Noumea) > 0 or
                len(self.__reportingRCS_DF_Noumea) > 0 or
                len(self.__reportingPN_DF_Gagi) > 0 or
                len(self.__reportingRCS_DF_Gagi) > 0 or
                len(self.__reportingPN_DF_Paris) > 0 or
                len(self.__reportingRCS_DF_Paris) > 0 or
                len(self.__reportingPN_DF_Intergreffe) > 0 or
                len(self.__reportingRCS_DF_Intergreffe) > 0 or
                len(self.__reportingPN_DF_TITMC) > 0 or
                len(self.__reportingRCS_DF_TITMC) > 0)

    def get_reportCentralisationPN_RCS(self):
        return True #self.__reportCentralisationPN_RCS

    def toString(self):
        print('Info controle traitement numero :', self.__idtrt)
        print('Date de contrôle : ', self.__datetrt)
        if len(self.__ctrljudiciaire) > 0:
            print('Liste des rejets judiciaires')
            for item in self.__ctrljudiciaire:
                print(item)

        if len(self.__ctrlcptxmlokko) > 0:
            print('Compteur centralisation  XML')
            for item in self.__ctrlcptxmlokko:
                print(item)

        if len(self.__ctrlcptgednbdoc) > 0:
            print('Compteur Nombre de documents')
            for item in self.__ctrlcptgednbdoc:
                print(item)

        if len(self.__ctrlcptgednbgrfout) > 0:
            print('Compteur Nombre de greffes out')
            for item in self.__ctrlcptgednbgrfout:
                print(item)

        if len(self.__ctrllstgrfout) > 0:
            print('liste de greffes out')
            for item in self.__ctrllstgrfout:
                print(item)

        if len(self.__ctrlprivetnan) > 0:
            print('Date de fraîcheur P&N')
            for item in self.__ctrlprivetnan:
                print(item)

        if len(self.__ctrlxml) > 0:
            print('Date de fraîcheur XML')
            for item in self.__ctrlxml:
                print(item)
